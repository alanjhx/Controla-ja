"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { ChevronLeft, ChevronRight, Check, X } from "lucide-react"
import { useRouter } from "next/navigation"
import { useLanguage } from "@/lib/language-context"
import { translations } from "@/lib/translations"
import { useAuth } from "@/lib/auth-context"

// Step icons
import { LayoutDashboard, ArrowUpDown, CreditCard, FileText, Search, MessageSquare, Bot, Target } from "lucide-react"

export function OnboardingFlow() {
  const [currentStep, setCurrentStep] = useState(0)
  const [showOnboarding, setShowOnboarding] = useState(false)
  const router = useRouter()
  const { language } = useLanguage()
  const t = translations[language]
  const { user } = useAuth()

  useEffect(() => {
    // Check if onboarding has been completed
    const hasCompletedOnboarding = localStorage.getItem("fincheck-onboarding-completed")
    if (!hasCompletedOnboarding) {
      setShowOnboarding(true)
    }
  }, [])

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      handleComplete()
    }
  }

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleComplete = () => {
    // Mark onboarding as completed
    localStorage.setItem("fincheck-onboarding-completed", "true")
    setShowOnboarding(false)
    router.push("/dashboard")
  }

  const handleSkip = () => {
    // Mark onboarding as completed but note that it was skipped
    localStorage.setItem("fincheck-onboarding-completed", "skipped")
    setShowOnboarding(false)
    router.push("/dashboard")
  }

  const StepIcon = ({ step }: { step: number }) => {
    const icons = [
      <LayoutDashboard key="dashboard" className="h-8 w-8" />,
      <ArrowUpDown key="expenses" className="h-8 w-8" />,
      <CreditCard key="cards" className="h-8 w-8" />,
      <FileText key="debts" className="h-8 w-8" />,
      <Search key="cpf" className="h-8 w-8" />,
      <MessageSquare key="whatsapp" className="h-8 w-8" />,
      <Bot key="ai" className="h-8 w-8" />,
      <Target key="goals" className="h-8 w-8" />,
    ]

    return (
      <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary text-primary-foreground">
        {icons[step]}
      </div>
    )
  }

  const steps = [
    {
      title: "Bem-vindo ao FinCheck",
      description: "Seu assistente financeiro pessoal",
      content: (
        <div className="space-y-4">
          <p>Olá, {user?.name?.split(" ")[0]}! Estamos felizes em tê-lo(a) conosco.</p>
          <p>
            O FinCheck é uma plataforma completa para gerenciar suas finanças pessoais, controlar despesas, gerenciar
            dívidas e alcançar seus objetivos financeiros.
          </p>
          <p>
            Vamos fazer um tour rápido pelas principais funcionalidades para que você possa começar a usar o sistema com
            facilidade.
          </p>
        </div>
      ),
    },
    {
      title: "Dashboard",
      description: "Visão geral das suas finanças",
      content: (
        <div className="space-y-4">
          <p>O Dashboard é sua página inicial, onde você tem uma visão geral de todas as suas finanças:</p>
          <ul className="space-y-2 list-disc pl-5">
            <li>Cartões de resumo mostram seu saldo total, receitas e despesas</li>
            <li>Gráficos de receitas e despesas por categoria</li>
            <li>Lista de transações recentes</li>
            <li>Acompanhamento de metas financeiras</li>
          </ul>
          <p>Você pode filtrar os dados por período (mês, trimestre, ano) para análises mais detalhadas.</p>
        </div>
      ),
    },
    {
      title: "Cadastro de Despesas",
      description: "Registre e organize suas transações",
      content: (
        <div className="space-y-4">
          <p>No Cadastro de Despesas, você pode:</p>
          <ul className="space-y-2 list-disc pl-5">
            <li>Adicionar novas despesas e receitas com detalhes completos</li>
            <li>Categorizar transações para melhor análise</li>
            <li>Adicionar tags personalizadas</li>
            <li>Definir recorrência (mensal, semanal, etc.)</li>
            <li>Filtrar e buscar suas transações</li>
          </ul>
          <p>Todas as alterações são refletidas automaticamente no Dashboard para acompanhamento em tempo real.</p>
        </div>
      ),
    },
    {
      title: "Cartões",
      description: "Gerencie seus cartões de crédito e débito",
      content: (
        <div className="space-y-4">
          <p>Na seção de Cartões, você pode:</p>
          <ul className="space-y-2 list-disc pl-5">
            <li>Adicionar todos os seus cartões (crédito, débito e virtuais)</li>
            <li>Acompanhar limites e saldos disponíveis</li>
            <li>Visualizar percentual de uso de cada cartão</li>
            <li>Organizar e categorizar seus cartões</li>
          </ul>
          <p>
            O sistema reconhece automaticamente as bandeiras dos cartões e aplica cores personalizadas para fácil
            identificação.
          </p>
        </div>
      ),
    },
    {
      title: "Planejador de Dívidas",
      description: "Acompanhe e planeje o pagamento de suas dívidas",
      content: (
        <div className="space-y-4">
          <p>O Planejador de Dívidas ajuda você a:</p>
          <ul className="space-y-2 list-disc pl-5">
            <li>Cadastrar todas as suas dívidas com detalhes completos</li>
            <li>Acompanhar o progresso de pagamento</li>
            <li>Visualizar distribuição de dívidas por tipo e credor</li>
            <li>Gerar planos de pagamento personalizados com IA</li>
            <li>Simular cenários de quitação</li>
          </ul>
          <p>O sistema também sugere a melhor estratégia para quitar suas dívidas mais rapidamente.</p>
        </div>
      ),
    },
    {
      title: "Radar CPF",
      description: "Monitore dívidas associadas ao seu CPF",
      content: (
        <div className="space-y-4">
          <p>O Radar CPF permite:</p>
          <ul className="space-y-2 list-disc pl-5">
            <li>Consultar dívidas associadas ao seu CPF</li>
            <li>Ver detalhes completos de cada dívida</li>
            <li>Analisar opções de pagamento e descontos disponíveis</li>
            <li>Importar dívidas diretamente para o Planejador</li>
          </ul>
          <p>
            Todas as consultas são realizadas com seu consentimento explícito e seguem as diretrizes da LGPD para
            proteção de dados.
          </p>
        </div>
      ),
    },
    {
      title: "Integração WhatsApp",
      description: "Gerencie suas finanças por mensagens",
      content: (
        <div className="space-y-4">
          <p>Com a integração do WhatsApp, você pode:</p>
          <ul className="space-y-2 list-disc pl-5">
            <li>Registrar despesas e receitas enviando mensagens simples</li>
            <li>Consultar seu saldo e transações recentes</li>
            <li>Receber alertas sobre movimentações</li>
            <li>Obter relatórios financeiros periódicos</li>
          </ul>
          <p>
            Basta conectar seu WhatsApp uma vez e começar a enviar comandos como "registrar despesa supermercado 150" ou
            "saldo atual".
          </p>
        </div>
      ),
    },
    {
      title: "Assistente de IA",
      description: "Seu consultor financeiro pessoal",
      content: (
        <div className="space-y-4">
          <p>O Assistente de IA oferece:</p>
          <ul className="space-y-2 list-disc pl-5">
            <li>Respostas a perguntas sobre suas finanças em linguagem natural</li>
            <li>Registro de transações por comando de voz ou texto</li>
            <li>Análise personalizada de seus gastos e comportamento financeiro</li>
            <li>Dicas de economia com base no seu perfil</li>
            <li>Sugestões proativas para melhorar sua saúde financeira</li>
          </ul>
          <p>O assistente aprende com suas interações e se torna cada vez mais personalizado com o tempo.</p>
        </div>
      ),
    },
    {
      title: "Pronto para começar!",
      description: "Você está preparado para controlar suas finanças",
      content: (
        <div className="space-y-4">
          <p>Parabéns, {user?.name?.split(" ")[0]}! Você já conhece as principais funcionalidades do FinCheck.</p>
          <p>
            Lembre-se de que você pode acessar o guia do usuário a qualquer momento clicando no botão de ajuda no canto
            inferior direito da tela.
          </p>
          <p>Recomendamos que você comece:</p>
          <ol className="space-y-2 list-decimal pl-5">
            <li>Cadastrando suas receitas e despesas</li>
            <li>Adicionando suas metas financeiras</li>
            <li>Registrando seus cartões e dívidas</li>
          </ol>
          <p className="font-medium">Estamos ansiosos para ajudá-lo(a) a alcançar seus objetivos financeiros!</p>
        </div>
      ),
    },
  ]

  if (!showOnboarding) return null

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader className="relative pb-0">
          <Button variant="ghost" size="icon" className="absolute right-4 top-4" onClick={handleSkip}>
            <X className="h-4 w-4" />
          </Button>
          <div className="flex flex-col sm:flex-row sm:items-center gap-4">
            <StepIcon step={currentStep} />
            <div>
              <CardTitle>{steps[currentStep].title}</CardTitle>
              <CardDescription>{steps[currentStep].description}</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="mb-6">
            <Progress value={(currentStep / (steps.length - 1)) * 100} className="h-2" />
            <div className="flex justify-between mt-2 text-xs text-muted-foreground">
              <span>Início</span>
              <span>{Math.round((currentStep / (steps.length - 1)) * 100)}%</span>
              <span>Fim</span>
            </div>
          </div>
          {steps[currentStep].content}
        </CardContent>
        <CardFooter className="flex justify-between border-t pt-6">
          <div>
            {currentStep > 0 ? (
              <Button variant="outline" onClick={handlePrevious}>
                <ChevronLeft className="mr-2 h-4 w-4" /> Anterior
              </Button>
            ) : (
              <Button variant="outline" onClick={handleSkip}>
                Pular tour
              </Button>
            )}
          </div>
          <Button onClick={handleNext}>
            {currentStep < steps.length - 1 ? (
              <>
                Próximo <ChevronRight className="ml-2 h-4 w-4" />
              </>
            ) : (
              <>
                Concluir <Check className="ml-2 h-4 w-4" />
              </>
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
