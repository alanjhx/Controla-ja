import Link from "next/link"
import { Facebook, Instagram, Linkedin, Twitter } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-gray-50 border-t border-gray-100">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <div className="flex items-center">
              <span className="text-xl font-bold text-teal-600">Controla Já</span>
            </div>
            <p className="mt-4 text-sm text-gray-600">Simplificando sua vida financeira desde 2020.</p>
            <div className="mt-6 flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-teal-600">
                <Facebook className="h-5 w-5" />
                <span className="sr-only">Facebook</span>
              </a>
              <a href="#" className="text-gray-400 hover:text-teal-600">
                <Instagram className="h-5 w-5" />
                <span className="sr-only">Instagram</span>
              </a>
              <a href="#" className="text-gray-400 hover:text-teal-600">
                <Twitter className="h-5 w-5" />
                <span className="sr-only">Twitter</span>
              </a>
              <a href="#" className="text-gray-400 hover:text-teal-600">
                <Linkedin className="h-5 w-5" />
                <span className="sr-only">LinkedIn</span>
              </a>
            </div>
          </div>
          <div>
            <h3 className="text-sm font-semibold text-gray-900 tracking-wider uppercase">Produto</h3>
            <ul className="mt-4 space-y-3">
              <li>
                <Link href="#features" className="text-sm text-gray-600 hover:text-teal-600">
                  Funcionalidades
                </Link>
              </li>
              <li>
                <Link href="#pricing" className="text-sm text-gray-600 hover:text-teal-600">
                  Planos e Preços
                </Link>
              </li>
              <li>
                <Link href="#" className="text-sm text-gray-600 hover:text-teal-600">
                  Aplicativo Mobile
                </Link>
              </li>
              <li>
                <Link href="#" className="text-sm text-gray-600 hover:text-teal-600">
                  Integrações
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold text-gray-900 tracking-wider uppercase">Empresa</h3>
            <ul className="mt-4 space-y-3">
              <li>
                <Link href="#" className="text-sm text-gray-600 hover:text-teal-600">
                  Sobre Nós
                </Link>
              </li>
              <li>
                <Link href="#" className="text-sm text-gray-600 hover:text-teal-600">
                  Blog
                </Link>
              </li>
              <li>
                <Link href="#" className="text-sm text-gray-600 hover:text-teal-600">
                  Carreiras
                </Link>
              </li>
              <li>
                <Link href="#testimonials" className="text-sm text-gray-600 hover:text-teal-600">
                  Depoimentos
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold text-gray-900 tracking-wider uppercase">Suporte</h3>
            <ul className="mt-4 space-y-3">
              <li>
                <Link href="#" className="text-sm text-gray-600 hover:text-teal-600">
                  Central de Ajuda
                </Link>
              </li>
              <li>
                <Link href="#" className="text-sm text-gray-600 hover:text-teal-600">
                  Contato
                </Link>
              </li>
              <li>
                <Link href="#" className="text-sm text-gray-600 hover:text-teal-600">
                  Política de Privacidade
                </Link>
              </li>
              <li>
                <Link href="#" className="text-sm text-gray-600 hover:text-teal-600">
                  Termos de Uso
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-12 border-t border-gray-200 pt-8">
          <p className="text-sm text-gray-500 text-center">
            &copy; {new Date().getFullYear()} Controla Já. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>\
