"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Bot, Send, Loader2, Sparkles, User, X } from "lucide-react"
import { useLanguage } from "@/lib/language-context"
import { translations } from "@/lib/translations"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useSupabase } from "@/lib/supabase-context"
import { formatCurrency } from "@/lib/currency-formatter"

interface Message {
  id: string
  role: "assistant" | "user" | "system"
  content: string
  timestamp: Date
}

export function AIAssistant() {
  const [messages, setMessages] = useState<Message[]>([])
  const [inputValue, setInputValue] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [context, setContext] = useState<any>({
    pendingTransaction: null,
    pendingAction: null,
    lastCategory: null,
  })
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const { language, currency } = useLanguage()
  const t = translations[language]
  const { transactions, categories, addTransaction } = useSupabase()

  // Load conversation history from localStorage
  useEffect(() => {
    const savedMessages = localStorage.getItem("ai-assistant-messages")
    if (savedMessages) {
      try {
        setMessages(JSON.parse(savedMessages))
      } catch (error) {
        console.error("Error parsing saved messages:", error)
      }
    } else {
      // Add initial greeting
      const initialMessage: Message = {
        id: `msg-${Date.now()}`,
        role: "assistant",
        content: "Olá! Sou o assistente financeiro do FinCheck. Como posso ajudar você hoje?",
        timestamp: new Date(),
      }
      setMessages([initialMessage])
    }
  }, [])

  // Save messages to localStorage when they change
  useEffect(() => {
    if (messages.length > 0) {
      localStorage.setItem("ai-assistant-messages", JSON.stringify(messages))
    }
  }, [messages])

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return

    // Add user message
    const userMessage: Message = {
      id: `msg-${Date.now()}`,
      role: "user",
      content: inputValue,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputValue("")
    setIsLoading(true)

    // Process the message with context awareness
    setTimeout(() => {
      processUserMessage(userMessage.content)
      setIsLoading(false)
    }, 1000)
  }

  // Process user message with context awareness
  const processUserMessage = (userMessage: string) => {
    const lowerMessage = userMessage.toLowerCase()

    // Check if we have a pending transaction that needs more info
    if (context.pendingTransaction) {
      return continueTransactionFlow(lowerMessage)
    }

    // Check for transaction intent
    if (containsAmount(lowerMessage)) {
      return handleAmountDetection(lowerMessage)
    }

    // Check for specific patterns
    if (/despesa|gasto|paguei|comprei/i.test(lowerMessage)) {
      return startExpenseFlow(lowerMessage)
    }

    if (/receita|recebi|ganhei|salário|salario/i.test(lowerMessage)) {
      return startIncomeFlow(lowerMessage)
    }

    if (/saldo|total|resumo|quanto tenho/i.test(lowerMessage)) {
      return showBalance()
    }

    if (/economi[az]ar|poupar/i.test(lowerMessage)) {
      return showSavingsTips()
    }

    if (/dívida|divida|devo/i.test(lowerMessage)) {
      return showDebtManagementTips()
    }

    if (/obrigad|valeu|thanks/i.test(lowerMessage)) {
      return sendResponse("De nada! Estou aqui para ajudar. Tem mais alguma pergunta sobre suas finanças?")
    }

    if (/ajuda|help|como/i.test(lowerMessage)) {
      return showHelp()
    }

    // Default response with suggestions
    return sendResponse(
      "Entendi sua mensagem. Como posso ajudar com suas finanças hoje? Você pode:\n\n" +
        '• Registrar uma despesa (ex: "gastei 50 reais no supermercado")\n' +
        '• Registrar uma receita (ex: "recebi 1000 reais de salário")\n' +
        '• Consultar seu saldo (ex: "qual meu saldo atual?")\n' +
        '• Pedir dicas de economia (ex: "como economizar dinheiro?")',
    )
  }

  // Helper function to check if message contains a monetary amount
  const containsAmount = (message: string) => {
    return (
      /\d+[.,]?\d*\s*(reais|real|r\$|brl)/i.test(message) ||
      /[rR]\$\s*\d+[.,]?\d*/i.test(message) ||
      /\b\d+[.,]?\d*\b/.test(message)
    )
  }

  // Extract amount from message
  const extractAmount = (message: string) => {
    const amountRegex = /[rR]\$\s*(\d+[.,]?\d*)|(\d+[.,]?\d*)\s*(reais|real|r\$|brl)|(\b\d+[.,]?\d*\b)/i
    const match = message.match(amountRegex)

    if (match) {
      const amount = match[1] || match[2] || match[4]
      return Number.parseFloat(amount.replace(",", "."))
    }

    return null
  }

  // Handle when only an amount is detected
  const handleAmountDetection = (message: string) => {
    const amount = extractAmount(message)

    if (amount) {
      setContext({
        ...context,
        pendingTransaction: {
          amount,
          type: null,
          description: null,
          categoryId: null,
          date: new Date(),
        },
        pendingAction: "askTransactionType",
      })

      sendResponse(`Entendi que você mencionou ${formatCurrency(amount, currency)}. Isso é uma despesa ou uma receita?`)
    }
  }

  // Start expense flow
  const startExpenseFlow = (message: string) => {
    const amount = extractAmount(message)

    // Try to extract category
    let categoryId = null
    let description = null

    // Simple category detection
    for (const category of categories.filter((c) => c.type === "expense")) {
      if (message.toLowerCase().includes(category.name.toLowerCase())) {
        categoryId = category.id
        break
      }
    }

    // Extract description (simple approach)
    const commonWords = ["despesa", "gasto", "paguei", "comprei", "reais", "real"]
    const words = message.split(/\s+/)
    const relevantWords = words.filter(
      (word) => !commonWords.includes(word.toLowerCase()) && !/^\d+([.,]\d+)?$/.test(word) && word.length > 2,
    )

    if (relevantWords.length > 0) {
      description = relevantWords.join(" ")
    }

    setContext({
      ...context,
      pendingTransaction: {
        amount: amount || null,
        type: "expense",
        description,
        categoryId,
        date: new Date(),
      },
      pendingAction: amount ? (categoryId ? "confirmTransaction" : "askCategory") : "askAmount",
    })

    if (!amount) {
      sendResponse("Qual foi o valor da despesa?")
    } else if (!categoryId) {
      sendResponse(`Entendi que você gastou ${formatCurrency(amount, currency)}. Em qual categoria?`)
    } else {
      const category = categories.find((c) => c.id === categoryId)
      sendResponse(
        `Confirma o registro de uma despesa de ${formatCurrency(amount, currency)} na categoria ${category?.name}?`,
      )
    }
  }

  // Start income flow
  const startIncomeFlow = (message: string) => {
    const amount = extractAmount(message)

    // Try to extract category
    let categoryId = null
    let description = null

    // Simple category detection
    for (const category of categories.filter((c) => c.type === "income")) {
      if (message.toLowerCase().includes(category.name.toLowerCase())) {
        categoryId = category.id
        break
      }
    }

    // Extract description (simple approach)
    const commonWords = ["receita", "recebi", "ganhei", "salário", "salario", "reais", "real"]
    const words = message.split(/\s+/)
    const relevantWords = words.filter(
      (word) => !commonWords.includes(word.toLowerCase()) && !/^\d+([.,]\d+)?$/.test(word) && word.length > 2,
    )

    if (relevantWords.length > 0) {
      description = relevantWords.join(" ")
    }

    setContext({
      ...context,
      pendingTransaction: {
        amount: amount || null,
        type: "income",
        description,
        categoryId,
        date: new Date(),
      },
      pendingAction: amount ? (categoryId ? "confirmTransaction" : "askCategory") : "askAmount",
    })

    if (!amount) {
      sendResponse("Qual foi o valor da receita?")
    } else if (!categoryId) {
      sendResponse(`Entendi que você recebeu ${formatCurrency(amount, currency)}. Em qual categoria?`)
    } else {
      const category = categories.find((c) => c.id === categoryId)
      sendResponse(
        `Confirma o registro de uma receita de ${formatCurrency(amount, currency)} na categoria ${category?.name}?`,
      )
    }
  }

  // Continue transaction flow based on context
  const continueTransactionFlow = (message: string) => {
    const { pendingTransaction, pendingAction } = context

    switch (pendingAction) {
      case "askTransactionType":
        if (/despesa|gasto|saída|saida|paguei|comprei/i.test(message)) {
          setContext({
            ...context,
            pendingTransaction: { ...pendingTransaction, type: "expense" },
            pendingAction: "askCategory",
          })
          sendResponse(`Qual a categoria desta despesa de ${formatCurrency(pendingTransaction.amount, currency)}?`)
        } else if (/receita|entrada|recebi|ganhei/i.test(message)) {
          setContext({
            ...context,
            pendingTransaction: { ...pendingTransaction, type: "income" },
            pendingAction: "askCategory",
          })
          sendResponse(`Qual a categoria desta receita de ${formatCurrency(pendingTransaction.amount, currency)}?`)
        } else {
          sendResponse("Não entendi. Por favor, especifique se é uma despesa ou uma receita.")
        }
        break

      case "askAmount":
        const amount = extractAmount(message)
        if (amount) {
          setContext({
            ...context,
            pendingTransaction: { ...pendingTransaction, amount },
            pendingAction: "askCategory",
          })
          sendResponse(
            `Qual a categoria desta ${pendingTransaction.type === "expense" ? "despesa" : "receita"} de ${formatCurrency(amount, currency)}?`,
          )
        } else {
          sendResponse("Não consegui identificar o valor. Por favor, informe apenas o valor (ex: 50,00).")
        }
        break

      case "askCategory":
        // Try to match category
        let matchedCategory = null

        for (const category of categories.filter((c) => c.type === pendingTransaction.type)) {
          if (message.toLowerCase().includes(category.name.toLowerCase())) {
            matchedCategory = category
            break
          }
        }

        if (matchedCategory) {
          setContext({
            ...context,
            pendingTransaction: { ...pendingTransaction, categoryId: matchedCategory.id },
            pendingAction: "askDescription",
          })
          sendResponse(`Qual a descrição desta ${pendingTransaction.type === "expense" ? "despesa" : "receita"}?`)
        } else {
          // If no match, use the message as description and ask for confirmation
          setContext({
            ...context,
            pendingTransaction: {
              ...pendingTransaction,
              description: message,
              categoryId: categories.find((c) => c.type === pendingTransaction.type)?.id,
            },
            pendingAction: "confirmTransaction",
          })

          const category = categories.find((c) => c.id === context.pendingTransaction.categoryId)
          sendResponse(
            `Confirma o registro de ${pendingTransaction.type === "expense" ? "uma despesa" : "uma receita"} de ${formatCurrency(pendingTransaction.amount, currency)} na categoria ${category?.name} com descrição "${message}"?`,
          )
        }
        break

      case "askDescription":
        setContext({
          ...context,
          pendingTransaction: { ...pendingTransaction, description: message },
          pendingAction: "confirmTransaction",
        })

        const category = categories.find((c) => c.id === pendingTransaction.categoryId)
        sendResponse(
          `Confirma o registro de ${pendingTransaction.type === "expense" ? "uma despesa" : "uma receita"} de ${formatCurrency(pendingTransaction.amount, currency)} na categoria ${category?.name} com descrição "${message}"?`,
        )
        break

      case "confirmTransaction":
        if (/sim|confirmo|ok|yes|confirmar/i.test(message)) {
          // Save transaction
          const newTransaction = {
            description: pendingTransaction.description || "Transação via assistente",
            amount: pendingTransaction.amount,
            date: pendingTransaction.date.toISOString(),
            type: pendingTransaction.type,
            categoryId: pendingTransaction.categoryId,
          }

          addTransaction(newTransaction)
            .then(() => {
              sendResponse(
                `✅ ${pendingTransaction.type === "expense" ? "Despesa" : "Receita"} de ${formatCurrency(pendingTransaction.amount, currency)} registrada com sucesso!`,
              )
              // Reset context
              setContext({
                pendingTransaction: null,
                pendingAction: null,
                lastCategory: pendingTransaction.categoryId,
              })
            })
            .catch((error) => {
              console.error("Error adding transaction:", error)
              sendResponse("Ocorreu um erro ao registrar a transação. Por favor, tente novamente.")
            })
        } else if (/não|nao|no|cancelar|cancel/i.test(message)) {
          sendResponse("Transação cancelada. Posso ajudar com mais alguma coisa?")
          setContext({
            pendingTransaction: null,
            pendingAction: null,
            lastCategory: null,
          })
        } else {
          sendResponse("Não entendi. Por favor, confirme com 'sim' ou 'não'.")
        }
        break

      default:
        sendResponse("Não entendi. Como posso ajudar com suas finanças?")
        setContext({
          pendingTransaction: null,
          pendingAction: null,
          lastCategory: null,
        })
    }
  }

  // Show balance
  const showBalance = () => {
    // Calculate totals
    const totalIncome = transactions.filter((t) => t.type === "income").reduce((sum, t) => sum + t.amount, 0)

    const totalExpense = transactions.filter((t) => t.type === "expense").reduce((sum, t) => sum + t.amount, 0)

    const balance = totalIncome - totalExpense

    sendResponse(
      `📊 **Resumo Financeiro**\n\n` +
        `Saldo atual: ${formatCurrency(balance, currency)}\n` +
        `Receitas: ${formatCurrency(totalIncome, currency)}\n` +
        `Despesas: ${formatCurrency(totalExpense, currency)}\n\n` +
        `Economia: ${formatCurrency(totalIncome - totalExpense, currency)}`,
    )
  }

  // Show savings tips
  const showSavingsTips = () => {
    sendResponse(
      `💰 **Dicas para Economizar**\n\n` +
        `1. **Regra 50/30/20**: Destine 50% da sua renda para necessidades, 30% para desejos e 20% para poupança\n\n` +
        `2. **Reduza gastos com delivery**: Cozinhar em casa pode economizar até 70% dos gastos com alimentação\n\n` +
        `3. **Revise assinaturas**: Cancele serviços que você não usa com frequência\n\n` +
        `4. **Automatize sua poupança**: Configure transferências automáticas para sua conta poupança\n\n` +
        `5. **Compare preços**: Use aplicativos de comparação antes de fazer compras importantes`,
    )
  }

  // Show debt management tips
  const showDebtManagementTips = () => {
    sendResponse(
      `📝 **Gerenciamento de Dívidas**\n\n` +
        `1. **Método da Avalanche**: Pague primeiro as dívidas com juros mais altos\n\n` +
        `2. **Método da Bola de Neve**: Comece pelas dívidas menores para ganhar motivação\n\n` +
        `3. **Negocie suas dívidas**: Muitos credores oferecem descontos para pagamentos à vista\n\n` +
        `4. **Consolide suas dívidas**: Unifique dívidas com juros altos em uma única com juros menores\n\n` +
        `5. **Use o planejador de dívidas**: Acesse a aba "Planejador de Dívidas" no FinCheck para criar um plano personalizado`,
    )
  }

  // Show help
  const showHelp = () => {
    sendResponse(
      `🤖 **Como posso ajudar**\n\n` +
        `Posso ajudar você com:\n\n` +
        `• **Registrar transações**: Diga "gastei 50 reais no supermercado" ou "recebi 1000 de salário"\n\n` +
        `• **Consultar saldo**: Pergunte "qual meu saldo?" ou "resumo financeiro"\n\n` +
        `• **Dicas financeiras**: Pergunte "como economizar dinheiro" ou "como gerenciar dívidas"\n\n` +
        `• **Análise de gastos**: Pergunte "onde gastei mais este mês?"\n\n` +
        `Experimente me dizer o que você precisa com suas próprias palavras!`,
    )
  }

  // Send assistant response
  const sendResponse = (content: string) => {
    const assistantMessage: Message = {
      id: `msg-${Date.now()}`,
      role: "assistant",
      content,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, assistantMessage])
  }

  const clearConversation = () => {
    // Keep only the initial greeting
    const initialMessage: Message = {
      id: `msg-${Date.now()}`,
      role: "assistant",
      content: "Olá! Sou o assistente financeiro do FinCheck. Como posso ajudar você hoje?",
      timestamp: new Date(),
    }
    setMessages([initialMessage])
    localStorage.setItem("ai-assistant-messages", JSON.stringify([initialMessage]))

    // Reset context
    setContext({
      pendingTransaction: null,
      pendingAction: null,
      lastCategory: null,
    })
  }

  return (
    <Card className="flex flex-col h-full">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bot className="h-5 w-5 text-primary" />
            <CardTitle className="text-xl">Assistente Financeiro</CardTitle>
          </div>
          <Button variant="ghost" size="icon" onClick={clearConversation}>
            <Sparkles className="h-4 w-4" />
          </Button>
        </div>
        <CardDescription>Pergunte sobre suas finanças ou registre transações naturalmente</CardDescription>
      </CardHeader>
      <CardContent className="flex-1 overflow-hidden p-0">
        <ScrollArea className="h-full px-4">
          <div className="space-y-4 pt-1 pb-4">
            {messages.map((message) => (
              <div key={message.id} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
                <div className="flex items-start gap-3 max-w-[80%]">
                  {message.role !== "user" && (
                    <div className="flex h-8 w-8 shrink-0 select-none items-center justify-center rounded-md border bg-primary text-primary-foreground">
                      <Bot className="h-4 w-4" />
                    </div>
                  )}
                  <div
                    className={`rounded-lg px-4 py-3 ${
                      message.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"
                    }`}
                  >
                    {message.content.split("\n").map((line, i) => (
                      <p key={i} className={i > 0 ? "mt-2" : ""}>
                        {line}
                      </p>
                    ))}
                  </div>
                  {message.role === "user" && (
                    <div className="flex h-8 w-8 shrink-0 select-none items-center justify-center rounded-md border bg-background">
                      <User className="h-4 w-4" />
                    </div>
                  )}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="flex items-start gap-3 max-w-[80%]">
                  <div className="flex h-8 w-8 shrink-0 select-none items-center justify-center rounded-md border bg-primary text-primary-foreground">
                    <Bot className="h-4 w-4" />
                  </div>
                  <div className="rounded-lg px-4 py-3 bg-muted">
                    <div className="flex space-x-2">
                      <div className="w-2 h-2 rounded-full bg-muted-foreground animate-bounce"></div>
                      <div className="w-2 h-2 rounded-full bg-muted-foreground animate-bounce delay-75"></div>
                      <div className="w-2 h-2 rounded-full bg-muted-foreground animate-bounce delay-150"></div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>
      </CardContent>
      <CardFooter className="pt-4 pb-6">
        <form
          onSubmit={(e) => {
            e.preventDefault()
            handleSendMessage()
          }}
          className="flex w-full items-center space-x-2"
        >
          <Input
            id="message"
            placeholder="Digite sua mensagem aqui..."
            className="flex-1"
            autoComplete="off"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            disabled={isLoading}
          />
          <Button type="submit" size="icon" disabled={isLoading || !inputValue.trim()}>
            {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </Button>
        </form>
      </CardFooter>
    </Card>
  )
}

// Component for the sidebar
export function AIAssistantButton() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <>
      <Button
        variant="outline"
        size="icon"
        className="fixed bottom-20 right-6 h-12 w-12 rounded-full shadow-lg z-40 bg-secondary text-secondary-foreground hover:bg-secondary/90"
        onClick={() => setIsOpen(true)}
      >
        <Sparkles className="h-6 w-6" />
        <span className="sr-only">AI Assistant</span>
      </Button>

      {isOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-2xl h-[80vh]">
            <AIAssistant />
            <Button
              variant="outline"
              size="icon"
              className="absolute top-4 right-4 h-8 w-8 rounded-full bg-background"
              onClick={() => setIsOpen(false)}
            >
              <X className="h-4 w-4" />
              <span className="sr-only">Close</span>
            </Button>
          </div>
        </div>
      )}
    </>
  )
}
