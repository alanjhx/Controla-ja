"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import {
  LayoutDashboard,
  ArrowUpDown,
  CreditCard,
  FileText,
  Search,
  Settings,
  LogOut,
  Menu,
  MessageSquare,
  Sparkles,
} from "lucide-react"
import { ModeToggle } from "@/components/mode-toggle"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useLanguage } from "@/lib/language-context"
import { translations } from "@/lib/translations"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog"
import { useAuth, useUser } from "@/lib/auth-context"

interface SidebarProps extends React.HTMLAttributes<HTMLDivElement> {
  isCollapsed?: boolean
}

export function Sidebar({ className, isCollapsed = false }: SidebarProps) {
  const pathname = usePathname()
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [logoutDialogOpen, setLogoutDialogOpen] = useState(false)
  const [aiDialogOpen, setAiDialogOpen] = useState(false)

  const { language } = useLanguage()
  const t = translations[language]

  // Use authentication hooks
  const { logout } = useAuth()
  const user = useUser()

  // Add WhatsApp and AI Assistant routes
  const routes = [
    {
      href: "/dashboard",
      icon: LayoutDashboard,
      title: t.dashboard,
    },
    {
      href: "/expense-registry",
      icon: ArrowUpDown,
      title: t.expenseRegistry,
    },
    {
      href: "/cards",
      icon: CreditCard,
      title: t.cards,
    },
    {
      href: "/debt-planner",
      icon: FileText,
      title: t.debtPlanner,
    },
    {
      href: "/cpf-radar",
      icon: Search,
      title: t.cpfRadar,
    },
    {
      href: "/whatsapp-integration",
      icon: MessageSquare,
      title: "WhatsApp",
    },
    {
      href: "#",
      icon: Sparkles,
      title: "Assistente IA",
      action: () => setAiDialogOpen(true),
    },
    {
      href: "/settings",
      icon: Settings,
      title: t.settings,
    },
  ]

  const handleLogout = () => {
    logout()
    setLogoutDialogOpen(false)
    router.push("/login")
  }

  const handleRouteClick = (route: any) => {
    if (route.action) {
      route.action()
      setOpen(false)
    }
  }

  return (
    <>
      {/* Mobile Sidebar */}
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild className="md:hidden">
          <Button variant="ghost" size="icon" className="h-10 w-10">
            <Menu className="h-5 w-5" />
            <span className="sr-only">Toggle Menu</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="p-0">
          <div className="flex flex-col h-full">
            <div className="p-4 border-b">
              <div className="flex items-center">
                <div className="font-bold text-xl text-primary">FINCHECK</div>
              </div>
            </div>
            <ScrollArea className="flex-1">
              <div className="p-4">
                <div className="flex items-center gap-3 mb-8">
                  <Avatar>
                    <AvatarImage src={user.avatar} alt={user.name} />
                    <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium">
                      {t.hi} {user.name.split(" ")[0]},
                    </p>
                    <p className="text-xs text-muted-foreground">{t.welcomeBack}</p>
                  </div>
                </div>
                <nav className="space-y-2">
                  {routes.map((route) =>
                    route.action ? (
                      <Button
                        key={route.title}
                        variant="ghost"
                        className={cn(
                          "w-full justify-start px-3 py-2 text-sm font-normal",
                          pathname === route.href ? "bg-accent text-accent-foreground" : "text-muted-foreground",
                        )}
                        onClick={() => handleRouteClick(route)}
                      >
                        <route.icon className="h-5 w-5 mr-3" />
                        {route.title}
                      </Button>
                    ) : (
                      <Link
                        key={route.href}
                        href={route.href}
                        onClick={() => setOpen(false)}
                        className={cn(
                          "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-all hover:bg-accent",
                          pathname === route.href ? "bg-accent text-accent-foreground" : "text-muted-foreground",
                        )}
                      >
                        <route.icon className="h-5 w-5" />
                        {route.title}
                      </Link>
                    ),
                  )}
                </nav>
              </div>
            </ScrollArea>
            <div className="p-4 border-t">
              <div className="flex items-center justify-between">
                <Dialog open={logoutDialogOpen} onOpenChange={setLogoutDialogOpen}>
                  <DialogTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-9 w-9">
                      <LogOut className="h-5 w-5" />
                      <span className="sr-only">{t.logout}</span>
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>{t.confirmLogout}</DialogTitle>
                    </DialogHeader>
                    <p>{t.logoutConfirmMessage}</p>
                    <DialogFooter className="mt-4">
                      <Button variant="outline" onClick={() => setLogoutDialogOpen(false)}>
                        {t.cancel}
                      </Button>
                      <Button onClick={handleLogout}>{t.logout}</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
                <ModeToggle />
              </div>
            </div>
          </div>
        </SheetContent>
      </Sheet>

      {/* Desktop Sidebar */}
      <div
        className={cn(
          "hidden md:flex flex-col h-screen border-r bg-card",
          isCollapsed ? "w-[80px]" : "w-[250px]",
          className,
        )}
      >
        <div className="p-4 border-b">
          <div className="flex items-center justify-center md:justify-start">
            <div className={cn("font-bold text-xl text-primary", isCollapsed ? "hidden" : "block")}>FINCHECK</div>
            {isCollapsed && <div className="font-bold text-xl text-primary">FC</div>}
          </div>
        </div>
        <ScrollArea className="flex-1">
          <div className="p-4">
            {!isCollapsed && (
              <div className="flex items-center gap-3 mb-8">
                <Avatar>
                  <AvatarImage src={user.avatar} alt={user.name} />
                  <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-medium">
                    {t.hi} {user.name.split(" ")[0]},
                  </p>
                  <p className="text-xs text-muted-foreground">{t.welcomeBack}</p>
                </div>
              </div>
            )}
            <nav className="space-y-2">
              {routes.map((route) =>
                route.action ? (
                  <Button
                    key={route.title}
                    variant="ghost"
                    className={cn(
                      "w-full justify-start px-3 py-2 text-sm font-normal",
                      pathname === route.href ? "bg-accent text-accent-foreground" : "text-muted-foreground",
                      isCollapsed && "justify-center p-3",
                    )}
                    onClick={() => handleRouteClick(route)}
                  >
                    <route.icon className={cn("h-5 w-5", !isCollapsed && "mr-3")} />
                    {!isCollapsed && route.title}
                  </Button>
                ) : (
                  <Link
                    key={route.href}
                    href={route.href}
                    className={cn(
                      "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-all hover:bg-accent",
                      pathname === route.href ? "bg-accent text-accent-foreground" : "text-muted-foreground",
                      isCollapsed && "justify-center p-3",
                    )}
                  >
                    <route.icon className="h-5 w-5" />
                    {!isCollapsed && route.title}
                  </Link>
                ),
              )}
            </nav>
          </div>
        </ScrollArea>
        <div className="p-4 border-t">
          <div className={cn("flex items-center", isCollapsed ? "justify-center" : "justify-between")}>
            {!isCollapsed && (
              <Dialog open={logoutDialogOpen} onOpenChange={setLogoutDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-9 w-9">
                    <LogOut className="h-5 w-5" />
                    <span className="sr-only">{t.logout}</span>
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>{t.confirmLogout}</DialogTitle>
                  </DialogHeader>
                  <p>{t.logoutConfirmMessage}</p>
                  <DialogFooter className="mt-4">
                    <Button variant="outline" onClick={() => setLogoutDialogOpen(false)}>
                      {t.cancel}
                    </Button>
                    <Button onClick={handleLogout}>{t.logout}</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            )}
            <ModeToggle />
          </div>
        </div>
      </div>

      {/* AI Assistant Dialog */}
      <Dialog open={aiDialogOpen} onOpenChange={setAiDialogOpen}>
        <DialogContent className="sm:max-w-[600px] h-[80vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" />
              Assistente IA
            </DialogTitle>
          </DialogHeader>
          <div className="flex-1 overflow-hidden">
            {/* We'll implement the AI Assistant component separately */}
            <div className="h-full flex items-center justify-center text-muted-foreground">
              Assistente IA carregando...
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
