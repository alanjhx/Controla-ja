"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { LayoutDashboard, ArrowUpDown, CreditCard, FileText, Search } from "lucide-react"
import { useLanguage } from "@/lib/language-context"
import { translations } from "@/lib/translations"

export function MobileNav() {
  const pathname = usePathname()
  const { language } = useLanguage()
  const t = translations[language]

  const routes = [
    {
      href: "/dashboard",
      icon: LayoutDashboard,
      label: t.dashboard,
    },
    {
      href: "/expense-registry",
      icon: ArrowUpDown,
      label: t.expenseRegistry,
    },
    {
      href: "/cards",
      icon: CreditCard,
      label: t.cards,
    },
    {
      href: "/debt-planner",
      icon: FileText,
      label: t.debtPlanner,
    },
    {
      href: "/cpf-radar",
      icon: Search,
      label: t.cpfRadar,
    },
  ]

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 md:hidden bg-black border-t border-gray-800">
      <div className="flex items-center justify-around h-16">
        {routes.map((route) => (
          <Link
            key={route.href}
            href={route.href}
            className={cn(
              "flex flex-col items-center justify-center w-full h-full text-xs",
              pathname === route.href ? "text-primary" : "text-gray-400 hover:text-gray-300",
            )}
          >
            <route.icon className="h-5 w-5 mb-1" />
            <span>{route.label}</span>
          </Link>
        ))}
      </div>
    </div>
  )
}
