"use client"

import { useState } from "react"
import type { Goal } from "@/lib/types"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plane, Car, Plus, Target, Home, Briefcase, GraduationCap, Heart, Gift, ShoppingBag } from "lucide-react"
import { useLanguage } from "@/lib/language-context"
import { translations } from "@/lib/translations"
import { formatCurrency } from "@/lib/currency-formatter"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { cn } from "@/lib/utils"

interface GoalsCardProps {
  goals: Goal[]
}

export function GoalsCard({ goals: initialGoals }: GoalsCardProps) {
  const { language, currency } = useLanguage()
  const t = translations[language]
  const [goals, setGoals] = useState<Goal[]>(initialGoals)
  const [newGoal, setNewGoal] = useState({
    name: "",
    targetAmount: 0,
    currentAmount: 0,
    icon: "target",
  })
  const [open, setOpen] = useState(false)
  const [formattedTarget, setFormattedTarget] = useState("")
  const [formattedCurrent, setFormattedCurrent] = useState("")

  const iconOptions = [
    { value: "target", label: t.target || "Target", icon: <Target className="h-5 w-5" /> },
    { value: "plane", label: t.travel || "Travel", icon: <Plane className="h-5 w-5" /> },
    { value: "car", label: t.car || "Car", icon: <Car className="h-5 w-5" /> },
    { value: "home", label: t.home || "Home", icon: <Home className="h-5 w-5" /> },
    { value: "briefcase", label: t.investment || "Investment", icon: <Briefcase className="h-5 w-5" /> },
    { value: "graduation", label: t.education || "Education", icon: <GraduationCap className="h-5 w-5" /> },
    { value: "heart", label: t.health || "Health", icon: <Heart className="h-5 w-5" /> },
    { value: "gift", label: t.gift || "Gift", icon: <Gift className="h-5 w-5" /> },
    { value: "shopping", label: t.shopping || "Shopping", icon: <ShoppingBag className="h-5 w-5" /> },
  ]

  const getIconComponent = (iconName: string) => {
    const iconOption = iconOptions.find((option) => option.value === iconName)
    return iconOption ? iconOption.icon : <Target className="h-5 w-5" />
  }

  const handleAddGoal = () => {
    if (newGoal.name && newGoal.targetAmount > 0) {
      const goal: Goal = {
        id: `goal-${Date.now()}`,
        name: newGoal.name,
        targetAmount: newGoal.targetAmount,
        currentAmount: newGoal.currentAmount,
        icon: newGoal.icon,
      }

      setGoals([...goals, goal])
      setNewGoal({
        name: "",
        targetAmount: 0,
        currentAmount: 0,
        icon: "target",
      })
      setFormattedTarget("")
      setFormattedCurrent("")
      setOpen(false)
    }
  }

  const handleTargetAmountChange = (value: string) => {
    // Remove non-numeric characters
    const numericValue = value.replace(/\D/g, "")

    // Convert to number (in cents)
    const amountInCents = numericValue ? Number.parseInt(numericValue, 10) : 0

    // Update state with the numeric value (in currency units)
    setNewGoal({ ...newGoal, targetAmount: amountInCents / 100 })

    // Format for display
    if (amountInCents === 0) {
      setFormattedTarget("")
    } else {
      setFormattedTarget(formatCurrency(amountInCents / 100, currency).replace(/[^\d,]/g, ""))
    }
  }

  const handleCurrentAmountChange = (value: string) => {
    // Remove non-numeric characters
    const numericValue = value.replace(/\D/g, "")

    // Convert to number (in cents)
    const amountInCents = numericValue ? Number.parseInt(numericValue, 10) : 0

    // Update state with the numeric value (in currency units)
    setNewGoal({ ...newGoal, currentAmount: amountInCents / 100 })

    // Format for display
    if (amountInCents === 0) {
      setFormattedCurrent("")
    } else {
      setFormattedCurrent(formatCurrency(amountInCents / 100, currency).replace(/[^\d,]/g, ""))
    }
  }

  return (
    <Card className="border shadow-sm h-full">
      <CardHeader className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-2 gap-2">
        <CardTitle className="text-md font-medium">{t.myGoals}</CardTitle>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm" variant="outline" className="h-8 gap-1 w-full sm:w-auto">
              <Plus className="h-4 w-4" /> {t.addGoal}
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{t.addNewGoal}</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">{t.goalName}</Label>
                <Input
                  id="name"
                  value={newGoal.name}
                  onChange={(e) => setNewGoal({ ...newGoal, name: e.target.value })}
                  placeholder={t.goalNamePlaceholder}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="target">{t.targetAmount}</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                    {currency === "BRL" ? "R$" : currency}
                  </span>
                  <Input
                    id="target"
                    value={formattedTarget}
                    onChange={(e) => handleTargetAmountChange(e.target.value)}
                    placeholder="0,00"
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="current">{t.currentAmount}</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                    {currency === "BRL" ? "R$" : currency}
                  </span>
                  <Input
                    id="current"
                    value={formattedCurrent}
                    onChange={(e) => handleCurrentAmountChange(e.target.value)}
                    placeholder="0,00"
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="icon">{t.icon}</Label>
                <div className="grid grid-cols-3 gap-2">
                  {iconOptions.map((option) => (
                    <div key={option.value} className="flex flex-col items-center">
                      <Button
                        type="button"
                        variant={newGoal.icon === option.value ? "default" : "outline"}
                        className={cn(
                          "h-16 w-full flex flex-col gap-1 items-center justify-center",
                          newGoal.icon === option.value ? "border-2 border-primary" : "",
                        )}
                        onClick={() => setNewGoal({ ...newGoal, icon: option.value })}
                      >
                        {option.icon}
                        <span className="text-xs">{option.label}</span>
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button type="submit" onClick={handleAddGoal}>
                {t.addGoal}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {goals.length === 0 ? (
            <div className="text-center py-6 text-muted-foreground">
              <Target className="h-12 w-12 mx-auto mb-2 opacity-50" />
              <p>{t.noGoalsYet}</p>
              <p className="text-sm">{t.addYourFirstGoal}</p>
            </div>
          ) : (
            goals.map((goal) => {
              const progressPercentage = Math.round((goal.currentAmount / goal.targetAmount) * 100)

              return (
                <div key={goal.id} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-primary">
                        {getIconComponent(goal.icon)}
                      </div>
                      <div>
                        <div className="font-medium">{t[goal.name.toLowerCase()] || goal.name}</div>
                        <div className="text-xs text-muted-foreground">
                          {formatCurrency(goal.currentAmount, currency)} {t.of}{" "}
                          {formatCurrency(goal.targetAmount, currency)}
                        </div>
                      </div>
                    </div>
                    <div className="text-sm font-medium">{progressPercentage}%</div>
                  </div>
                  <div className="h-2 w-full rounded-full bg-muted">
                    <div
                      className="h-2 rounded-full bg-primary transition-all duration-500 ease-in-out"
                      style={{ width: `${progressPercentage}%` }}
                    />
                  </div>
                </div>
              )
            })
          )}
        </div>
      </CardContent>
    </Card>
  )
}
