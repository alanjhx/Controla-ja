"use client"

import { cn } from "@/lib/utils"
import { ArrowUpRight, ArrowDownRight, Info } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { useLanguage } from "@/lib/language-context"
import { formatCurrency } from "@/lib/currency-formatter"
import { translations } from "@/lib/translations"
import { useState } from "react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface SummaryCardProps {
  title: string
  amount: number
  percentChange?: number
  period?: string
  variant: "primary" | "secondary" | "tertiary" | "quaternary"
  details?: { label: string; value: string | number }[]
}

export function SummaryCard({
  title,
  amount,
  percentChange,
  period = "from last month",
  variant = "primary",
  details = [],
}: SummaryCardProps) {
  const isPositive = percentChange && percentChange > 0
  const { currency, language } = useLanguage()
  const t = translations[language]
  const [isExpanded, setIsExpanded] = useState(false)

  const variantStyles = {
    primary: "bg-cyan-500 text-primary-foreground",
    secondary: "bg-blue-500 text-secondary-foreground",
    tertiary: "bg-green-500 text-tertiary-foreground",
    quaternary: "bg-purple-500 text-quaternary-foreground",
  }

  return (
    <Card
      className={cn(
        "border-none shadow-sm h-full transition-all duration-300 cursor-pointer rounded-xl overflow-hidden",
        variantStyles[variant],
        isExpanded && "scale-105 z-10",
      )}
      onClick={() => setIsExpanded(!isExpanded)}
    >
      <CardContent className="p-4 sm:p-6">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium opacity-90">{title}</p>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Info className="h-4 w-4 opacity-80 hover:opacity-100" />
                </TooltipTrigger>
                <TooltipContent>
                  <p>{t.comparedToLastMonth || "Comparado ao mês anterior"}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <div className="flex items-baseline justify-between">
            <h2 className="text-xl sm:text-2xl font-bold">{formatCurrency(amount, currency)}</h2>
            {percentChange !== undefined && (
              <div
                className={cn(
                  "flex items-center text-xs sm:text-sm font-medium px-2 py-1 rounded-full max-w-[90px] truncate",
                  isPositive
                    ? "text-green-100 bg-green-600/30 dark:text-green-300 dark:bg-green-900/50"
                    : "text-red-100 bg-red-600/30 dark:text-red-300 dark:bg-red-900/50",
                )}
              >
                {isPositive ? (
                  <ArrowUpRight className="mr-1 h-3 w-3 flex-shrink-0" />
                ) : (
                  <ArrowDownRight className="mr-1 h-3 w-3 flex-shrink-0" />
                )}
                <span className="truncate">{Math.abs(percentChange)}%</span>
              </div>
            )}
          </div>
          {period && <p className="text-xs opacity-80">{t[period] || period}</p>}

          {isExpanded && details.length > 0 && (
            <div className="mt-4 pt-4 border-t border-white/20 space-y-2">
              {details.map((detail, index) => (
                <div key={index} className="flex justify-between items-center">
                  <span className="text-sm opacity-80">{detail.label}</span>
                  <span className="text-sm font-medium">{detail.value}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
