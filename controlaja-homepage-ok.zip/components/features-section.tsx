import { BarChart3, CreditCard, LineChart, Shield, Smartphone, Wallet } from "lucide-react"

const features = [
  {
    name: "Controle de Despesas",
    description: "Acompanhe todos os seus gastos em um só lugar, com categorização automática e relatórios detalhados.",
    icon: Wallet,
  },
  {
    name: "Sincronização Bancária",
    description: "Conecte suas contas bancárias e cartões para importação automática de transações.",
    icon: CreditCard,
  },
  {
    name: "Relatórios Detalhados",
    description: "Visualize sua saúde financeira com gráficos e relatórios personalizados.",
    icon: BarChart3,
  },
  {
    name: "Metas Financeiras",
    description: "Defina objetivos financeiros e acompanhe seu progresso em tempo real.",
    icon: LineChart,
  },
  {
    name: "Aplicativo Mobile",
    description: "Acesse suas finanças de qualquer lugar com nosso aplicativo para iOS e Android.",
    icon: Smartphone,
  },
  {
    name: "Segurança Avançada",
    description: "Seus dados financeiros protegidos com criptografia de ponta a ponta.",
    icon: Shield,
  },
]

export default function FeaturesSection() {
  return (
    <section id="features" className="py-16 sm:py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">
            Funcionalidades que simplificam sua vida financeira
          </h2>
          <p className="mt-4 text-lg text-gray-600">
            Conheça as ferramentas que vão transformar a maneira como você gerencia seu dinheiro.
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-x-8 gap-y-12 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature) => (
            <div key={feature.name} className="relative">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-teal-100 text-teal-600">
                <feature.icon className="h-6 w-6" aria-hidden="true" />
              </div>
              <div className="mt-5">
                <h3 className="text-lg font-semibold text-gray-900">{feature.name}</h3>
                <p className="mt-2 text-base text-gray-600">{feature.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
