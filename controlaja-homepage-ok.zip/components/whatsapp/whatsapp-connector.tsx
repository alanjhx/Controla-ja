"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { QRCodeSVG } from "qrcode.react"
import { useToast } from "@/components/ui/use-toast"
import { Loader2, Check, Copy, RefreshCw, Send } from "lucide-react"
import { useLanguage } from "@/lib/language-context"
import { translations } from "@/lib/translations"

export function WhatsAppConnector() {
  const [phoneNumber, setPhoneNumber] = useState("")
  const [isConnecting, setIsConnecting] = useState(false)
  const [isConnected, setIsConnected] = useState(false)
  const [qrCodeData, setQrCodeData] = useState("")
  const [activeTab, setActiveTab] = useState("connect")
  const [message, setMessage] = useState("")
  const [isSending, setIsSending] = useState(false)
  const { toast } = useToast()
  const { language } = useLanguage()
  const t = translations[language]

  // Check if already connected
  useEffect(() => {
    const savedConnection = localStorage.getItem("whatsapp-connection")
    if (savedConnection) {
      try {
        const connectionData = JSON.parse(savedConnection)
        if (connectionData.connected && connectionData.phone) {
          setIsConnected(true)
          setPhoneNumber(connectionData.phone)
        }
      } catch (error) {
        console.error("Error parsing saved WhatsApp connection:", error)
      }
    }
  }, [])

  const handleGenerateQRCode = () => {
    if (!phoneNumber || !phoneNumber.match(/^\+\d{10,15}$/)) {
      toast({
        title: "Número inválido",
        description: "Por favor, insira um número de telefone válido com código do país (ex: +5511987654321)",
        variant: "destructive",
      })
      return
    }

    setIsConnecting(true)

    // Simulate API call to generate QR code
    setTimeout(() => {
      // Generate a random QR code data for demo purposes
      const randomData = `whatsapp://connect?phone=${phoneNumber}&token=${Math.random().toString(36).substring(2, 15)}`
      setQrCodeData(randomData)
      setIsConnecting(false)

      // Simulate successful connection after 3 seconds
      setTimeout(() => {
        setIsConnected(true)
        localStorage.setItem(
          "whatsapp-connection",
          JSON.stringify({
            connected: true,
            phone: phoneNumber,
            timestamp: new Date().toISOString(),
          }),
        )
        toast({
          title: "WhatsApp conectado",
          description: "Seu WhatsApp foi conectado com sucesso!",
        })
      }, 3000)
    }, 1500)
  }

  const handleDisconnect = () => {
    setIsConnected(false)
    setQrCodeData("")
    localStorage.removeItem("whatsapp-connection")
    toast({
      title: "WhatsApp desconectado",
      description: "Seu WhatsApp foi desconectado com sucesso.",
    })
  }

  const handleCopyNumber = () => {
    navigator.clipboard.writeText(phoneNumber)
    toast({
      title: "Número copiado",
      description: "O número de telefone foi copiado para a área de transferência.",
    })
  }

  const handleSendMessage = () => {
    if (!message.trim()) {
      toast({
        title: "Mensagem vazia",
        description: "Por favor, digite uma mensagem para enviar.",
        variant: "destructive",
      })
      return
    }

    setIsSending(true)

    // Simulate sending message
    setTimeout(() => {
      setIsSending(false)
      setMessage("")
      toast({
        title: "Mensagem enviada",
        description: "Sua mensagem foi enviada com sucesso!",
      })
    }, 1500)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Integração com WhatsApp</CardTitle>
        <CardDescription>Gerencie suas finanças diretamente pelo WhatsApp.</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="connect">Conectar</TabsTrigger>
            <TabsTrigger value="commands">Comandos</TabsTrigger>
            <TabsTrigger value="settings">Configurações</TabsTrigger>
          </TabsList>
          <TabsContent value="connect" className="space-y-4 pt-4">
            {isConnected ? (
              <div className="space-y-4">
                <div className="flex items-center justify-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <div className="flex items-center gap-2 text-green-600 dark:text-green-400">
                    <Check className="h-5 w-5" />
                    <span className="font-medium">WhatsApp conectado</span>
                  </div>
                </div>

                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="text-sm text-muted-foreground">Número conectado</p>
                    <p className="font-medium">{phoneNumber}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="icon" onClick={handleCopyNumber}>
                      <Copy className="h-4 w-4" />
                    </Button>
                    <Button variant="destructive" onClick={handleDisconnect}>
                      Desconectar
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Enviar mensagem de teste</h3>
                  <div className="flex gap-2">
                    <Input
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Digite uma mensagem..."
                      disabled={isSending}
                    />
                    <Button onClick={handleSendMessage} disabled={isSending}>
                      {isSending ? (
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      ) : (
                        <Send className="h-4 w-4 mr-2" />
                      )}
                      Enviar
                    </Button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="space-y-2">
                  <label htmlFor="phone" className="text-sm font-medium">
                    Número de telefone
                  </label>
                  <Input
                    id="phone"
                    placeholder="+5511987654321"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">Digite seu número de WhatsApp com código do país.</p>
                </div>

                <Button onClick={handleGenerateQRCode} disabled={isConnecting} className="w-full">
                  {isConnecting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Gerando QR Code...
                    </>
                  ) : (
                    <>Gerar QR Code</>
                  )}
                </Button>

                {qrCodeData && (
                  <div className="flex flex-col items-center justify-center p-4 border rounded-lg">
                    <QRCodeSVG value={qrCodeData} size={200} />
                    <p className="mt-4 text-sm text-center text-muted-foreground">
                      Escaneie este QR Code com seu WhatsApp para conectar
                    </p>
                    <Button variant="outline" size="sm" className="mt-2" onClick={handleGenerateQRCode}>
                      <RefreshCw className="mr-2 h-4 w-4" />
                      Gerar novo código
                    </Button>
                  </div>
                )}
              </div>
            )}
          </TabsContent>
          <TabsContent value="commands" className="pt-4">
            <div className="space-y-4">
              <div className="border rounded-lg divide-y">
                <div className="p-3">
                  <h3 className="font-medium">Consultar saldo</h3>
                  <p className="text-sm text-muted-foreground">Envie "saldo" ou "resumo" para ver seu saldo atual</p>
                </div>
                <div className="p-3">
                  <h3 className="font-medium">Registrar despesa</h3>
                  <p className="text-sm text-muted-foreground">
                    Envie "despesa [valor] [categoria]" para registrar uma despesa
                  </p>
                </div>
                <div className="p-3">
                  <h3 className="font-medium">Registrar receita</h3>
                  <p className="text-sm text-muted-foreground">
                    Envie "receita [valor] [descrição]" para registrar uma receita
                  </p>
                </div>
                <div className="p-3">
                  <h3 className="font-medium">Ver transações recentes</h3>
                  <p className="text-sm text-muted-foreground">Envie "transações" para ver suas transações recentes</p>
                </div>
                <div className="p-3">
                  <h3 className="font-medium">Ajuda</h3>
                  <p className="text-sm text-muted-foreground">Envie "ajuda" para ver todos os comandos disponíveis</p>
                </div>
              </div>
            </div>
          </TabsContent>
          <TabsContent value="settings" className="pt-4">
            <div className="space-y-4">
              <div className="space-y-2">
                <h3 className="text-sm font-medium">Notificações</h3>
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">Alertas diários</p>
                    <p className="text-sm text-muted-foreground">Receba um resumo diário das suas finanças</p>
                  </div>
                  <Button variant="outline">Ativar</Button>
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">Alertas de gastos</p>
                    <p className="text-sm text-muted-foreground">Receba alertas quando ultrapassar seu orçamento</p>
                  </div>
                  <Button variant="outline">Ativar</Button>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Privacidade</h3>
                <div className="p-3 border rounded-lg">
                  <p className="text-sm">
                    Suas mensagens são criptografadas e seus dados financeiros são armazenados com segurança. Não
                    compartilhamos suas informações com terceiros.
                  </p>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-between">
        <p className="text-xs text-muted-foreground">Powered by FinCheck WhatsApp Integration</p>
      </CardFooter>
    </Card>
  )
}
