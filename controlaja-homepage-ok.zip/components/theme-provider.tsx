"use client"

import * as React from "react"
import { ThemeProvider as NextThemesProvider } from "next-themes"
import type { ThemeProviderProps } from "next-themes/dist/types"

export function ThemeProvider({ children, ...props }: ThemeProviderProps) {
  // Adicionar um efeito para garantir que o tema seja aplicado corretamente
  React.useEffect(() => {
    // Observar mudanças no tema
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === "attributes" && mutation.attributeName === "class") {
          const isDark = document.documentElement.classList.contains("dark")
          document.documentElement.style.colorScheme = isDark ? "dark" : "light"
        }
      })
    })

    // Iniciar observação
    observer.observe(document.documentElement, { attributes: true })

    // Limpar observador
    return () => observer.disconnect()
  }, [])

  return <NextThemesProvider {...props}>{children}</NextThemesProvider>
}
