"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

type Language = "en" | "pt" | "es" | "fr"
type Currency = "USD" | "BRL" | "EUR"

interface LanguageContextType {
  language: Language
  setLanguage: (language: Language) => void
  currency: Currency
  setCurrency: (currency: Currency) => void
}

const defaultLanguage: Language = "en"
const defaultCurrency: Currency = "USD"

export const LanguageContext = createContext<LanguageContextType>({
  language: defaultLanguage,
  setLanguage: () => {},
  currency: defaultCurrency,
  setCurrency: () => {},
})

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>(defaultLanguage)
  const [currency, setCurrencyState] = useState<Currency>(defaultCurrency)

  // Initialize language from localStorage or browser settings on mount
  useEffect(() => {
    // Try to get language from localStorage
    const savedLanguage = localStorage.getItem("fincheck-language") as Language

    if (savedLanguage && ["en", "pt", "es", "fr"].includes(savedLanguage)) {
      setLanguageState(savedLanguage)

      // Set appropriate currency based on language
      const currencyMap: Record<Language, Currency> = {
        en: "USD",
        pt: "BRL",
        es: "EUR",
        fr: "EUR",
      }
      setCurrencyState(currencyMap[savedLanguage])
    } else {
      // If no saved language, detect from browser
      const browserLanguage = navigator.language.split("-")[0]

      // Map browser language to supported languages
      let detectedLanguage: Language = defaultLanguage
      if (browserLanguage === "pt") detectedLanguage = "pt"
      else if (browserLanguage === "es") detectedLanguage = "es"
      else if (browserLanguage === "fr") detectedLanguage = "fr"

      setLanguageState(detectedLanguage)

      // Set appropriate currency based on detected language
      const currencyMap: Record<Language, Currency> = {
        en: "USD",
        pt: "BRL",
        es: "EUR",
        fr: "EUR",
      }
      setCurrencyState(currencyMap[detectedLanguage])
    }
  }, [])

  // Set language and save to localStorage
  const setLanguage = (newLanguage: Language) => {
    setLanguageState(newLanguage)
    localStorage.setItem("fincheck-language", newLanguage)
  }

  // Set currency and save to localStorage
  const setCurrency = (newCurrency: Currency) => {
    setCurrencyState(newCurrency)
    localStorage.setItem("fincheck-currency", newCurrency)
  }

  return (
    <LanguageContext.Provider value={{ language, setLanguage, currency, setCurrency }}>
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  return useContext(LanguageContext)
}
