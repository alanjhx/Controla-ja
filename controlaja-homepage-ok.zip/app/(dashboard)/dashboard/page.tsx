"use client"

import { useState, useEffect } from "react"
import { SummaryCard } from "@/components/dashboard/summary-card"
import { LineChart } from "@/components/dashboard/line-chart"
import { PieChart } from "@/components/dashboard/pie-chart"
import { TransactionList } from "@/components/dashboard/transaction-list"
import { GoalsCard } from "@/components/dashboard/goals-card"
import { Skeleton } from "@/components/ui/skeleton"
import { useLanguage } from "@/lib/language-context"
import { translations } from "@/lib/translations"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent } from "@/components/ui/card"
import { StatisticsOverview } from "@/components/dashboard/statistics-overview"
import { useUser } from "@/lib/auth-context"
import { useSupabase } from "@/lib/supabase-context"
import { useRouter } from "next/navigation"

function DashboardSkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {Array(4)
          .fill(0)
          .map((_, i) => (
            <Skeleton key={i} className="h-[120px] rounded-lg" />
          ))}
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <Skeleton className="h-[300px] rounded-lg" />
        <Skeleton className="h-[300px] rounded-lg" />
      </div>
      <div className="grid gap-4 md:grid-cols-3">
        <Skeleton className="h-[400px] rounded-lg md:col-span-2" />
        <Skeleton className="h-[400px] rounded-lg" />
      </div>
    </div>
  )
}

export default function DashboardPage() {
  const [period, setPeriod] = useState("thisMonth")
  const { language } = useLanguage()
  const t = translations[language]
  const router = useRouter()

  // Use Supabase context for global state
  const { transactions, categories, goals, isLoading, getTotals } = useSupabase()

  // Use the user context
  const user = useUser()

  // Calculate financial summary
  const [financialSummary, setFinancialSummary] = useState({
    totalBalance: 0,
    totalIncome: 0,
    totalExpenses: 0,
    totalSavings: 0,
  })

  // Update financial summary when transactions change
  useEffect(() => {
    if (!isLoading) {
      const totals = getTotals()
      setFinancialSummary({
        totalBalance: totals.balance,
        totalIncome: totals.income,
        totalExpenses: totals.expenses,
        totalSavings: totals.savings,
      })
    }
  }, [isLoading, transactions, getTotals])

  // Show skeleton while loading
  if (isLoading) {
    return <DashboardSkeleton />
  }

  // Details for the cards
  const balanceDetails = [
    { label: t.available || "Available", value: `R$ ${(financialSummary.totalBalance * 0.8).toFixed(2)}` },
    { label: t.emergencyFund || "Emergency Fund", value: `R$ ${(financialSummary.totalBalance * 0.2).toFixed(2)}` },
  ]

  const incomeDetails = [
    { label: t.salary || "Salary", value: `R$ ${(financialSummary.totalIncome * 0.75).toFixed(2)}` },
    { label: t.freelance || "Freelance", value: `R$ ${(financialSummary.totalIncome * 0.25).toFixed(2)}` },
  ]

  const expensesDetails = [
    { label: t.essential || "Essential", value: `R$ ${(financialSummary.totalExpenses * 0.7).toFixed(2)}` },
    { label: t.nonEssential || "Non-essential", value: `R$ ${(financialSummary.totalExpenses * 0.3).toFixed(2)}` },
  ]

  const savingsDetails = [
    { label: t.monthlyGoal || "Monthly Goal", value: `R$ ${(financialSummary.totalSavings * 1.05).toFixed(2)}` },
    { label: t.progress || "Progress", value: "95%" },
  ]

  // Generate monthly income data
  const monthlyIncomeData = [
    { month: "Jan", amount: 3200 },
    { month: "Feb", amount: 3400 },
    { month: "Mar", amount: 3100 },
    { month: "Apr", amount: 3800 },
    { month: "May", amount: 4200 },
    { month: "Jun", amount: 4100 },
    { month: "Jul", amount: 4300 },
    { month: "Aug", amount: 4500 },
    { month: "Sep", amount: financialSummary.totalIncome },
    { month: "Oct", amount: 0 },
    { month: "Nov", amount: 0 },
    { month: "Dec", amount: 0 },
  ]

  // Generate category distribution
  const categoryDistribution = categories
    .filter((category) => category.type === "expense")
    .map((category) => {
      const categoryTransactions = transactions.filter((t) => t.categoryId === category.id && t.type === "expense")
      const totalAmount = categoryTransactions.reduce((acc, curr) => acc + curr.amount, 0)
      const percentage =
        financialSummary.totalExpenses > 0 ? Math.round((totalAmount / financialSummary.totalExpenses) * 100) : 0

      return {
        category: t[category.name.toLowerCase()] || category.name,
        percentage,
      }
    })
    .filter((item) => item.percentage > 0)
    .sort((a, b) => b.percentage - a.percentage)

  // Filter transactions for transaction list
  const recentTransactions = transactions
    .slice() // Copy to avoid mutating
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()) // Sort by date (newest first)
    .slice(0, 10) // Take only top 10

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold tracking-tight">{t.dashboard}</h1>
        <Card className="w-full sm:w-auto bg-black text-white border-gray-800">
          <CardContent className="p-3 flex items-center gap-3">
            <Avatar className="h-10 w-10">
              <AvatarImage src={user.avatar} alt={user.name} />
              <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <p className="text-sm font-medium">{user.name}</p>
              <p className="text-xs text-gray-400">{user.email}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-3 sm:gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
        <SummaryCard
          title={t.totalBalance}
          amount={financialSummary.totalBalance}
          percentChange={8.2}
          period="fromLastMonth"
          variant="secondary"
          details={balanceDetails}
        />
        <SummaryCard
          title={t.totalIncome}
          amount={financialSummary.totalIncome}
          percentChange={4.5}
          period="fromLastMonth"
          variant="primary"
          details={incomeDetails}
        />
        <SummaryCard
          title={t.totalExpenses}
          amount={financialSummary.totalExpenses}
          percentChange={-2.4}
          period="fromLastMonth"
          variant="quaternary"
          details={expensesDetails}
        />
        <SummaryCard
          title={t.totalSavings}
          amount={financialSummary.totalSavings}
          percentChange={12.0}
          period="fromLastMonth"
          variant="tertiary"
          details={savingsDetails}
        />
      </div>

      <div className="grid gap-3 sm:gap-4 grid-cols-1 md:grid-cols-2">
        <LineChart data={monthlyIncomeData} title={t.incomeOverTime} onPeriodChange={setPeriod} />
        <PieChart
          data={categoryDistribution}
          title={t.expensesByCategory}
          centerText={financialSummary.totalExpenses.toString()}
          onPeriodChange={setPeriod}
        />
      </div>

      <div className="grid gap-3 sm:gap-4 grid-cols-1 md:grid-cols-3">
        <div className="md:col-span-2">
          <TransactionList transactions={recentTransactions} onViewAll={() => router.push("/transactions")} />
        </div>
        <div>
          <GoalsCard goals={goals} />
        </div>
      </div>

      {/* Statistics moved below transaction history and goals */}
      <div className="mt-8">
        <StatisticsOverview />
      </div>
    </div>
  )
}
