"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { ModeToggle } from "@/components/mode-toggle"
import { Checkbox } from "@/components/ui/checkbox"
import { Mail, Lock, Eye, EyeOff } from "lucide-react"
import { useLanguage } from "@/lib/language-context"
import { translations } from "@/lib/translations"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"

const formSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email address" }),
  password: z.string().min(6, { message: "Password must be at least 6 characters" }),
  rememberMe: z.boolean().default(false),
})

export default function LoginPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [loginError, setLoginError] = useState<string | null>(null)
  const { language, setLanguage, currency, setCurrency } = useLanguage()
  const t = translations[language]

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: "",
      password: "",
      rememberMe: false,
    },
  })

  // Modificar a função onSubmit para garantir que os dados do usuário sejam armazenados corretamente
  function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true)
    setLoginError(null)

    console.log("Tentando fazer login com:", values.email)

    // Simular API call com validação
    setTimeout(() => {
      setIsLoading(false)

      // Para fins de demonstração, vamos considerar qualquer email/senha como válido
      // Em um app real, isso seria uma chamada de API para validar credenciais
      const userData = {
        id: "1",
        name: "Adaline Horton",
        email: values.email,
        avatar: "/placeholder.svg?height=40&width=40",
        isLoggedIn: true,
      }

      // Aceitar qualquer email que pareça válido
      if (values.email.includes("@")) {
        if (values.rememberMe) {
          localStorage.setItem("fincheck-user", JSON.stringify(userData))
        } else {
          sessionStorage.setItem("fincheck-user", JSON.stringify(userData))
        }

        // Forçar um reload para garantir que os dados sejam aplicados
        window.location.href = "/dashboard"
      } else {
        setLoginError(t.invalidCredentials)
      }
    }, 1000)
  }

  const handleLanguageChange = (value: string) => {
    setLanguage(value)

    // Set appropriate currency based on language
    const currencyMap: Record<string, string> = {
      en: "USD",
      pt: "BRL",
      es: "EUR",
      fr: "EUR",
    }

    setCurrency(currencyMap[value] || "USD")
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5">
      <div className="flex items-center justify-between p-4">
        <Link href="/" className="font-bold text-xl text-primary">
          FINCHECK
        </Link>
        <div className="flex items-center gap-2">
          <Select value={language} onValueChange={handleLanguageChange}>
            <SelectTrigger className="w-[120px] h-8">
              <SelectValue placeholder={t.selectLanguage} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="en">English</SelectItem>
              <SelectItem value="pt">Português</SelectItem>
              <SelectItem value="es">Español</SelectItem>
              <SelectItem value="fr">Français</SelectItem>
            </SelectContent>
          </Select>
          <ModeToggle />
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-md">
          <div className="bg-card rounded-2xl shadow-lg border p-8">
            <div className="space-y-2 text-center mb-8">
              <h1 className="text-3xl font-bold">{t.welcomeBack}</h1>
              <p className="text-muted-foreground">{t.loginDescription}</p>
            </div>

            {loginError && (
              <Alert variant="destructive" className="mb-6">
                <AlertDescription>{loginError}</AlertDescription>
              </Alert>
            )}

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t.email}</FormLabel>
                      <div className="relative">
                        <Mail className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
                        <FormControl>
                          <Input placeholder="name@example.com" className="pl-10" {...field} />
                        </FormControl>
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t.password}</FormLabel>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
                        <FormControl>
                          <Input
                            type={showPassword ? "text" : "password"}
                            placeholder="••••••••"
                            className="pl-10"
                            {...field}
                          />
                        </FormControl>
                        <button
                          type="button"
                          className="absolute right-3 top-3 text-muted-foreground hover:text-foreground"
                          onClick={() => setShowPassword(!showPassword)}
                        >
                          {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                          <span className="sr-only">{showPassword ? t.hidePassword : t.showPassword}</span>
                        </button>
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex items-center justify-between">
                  <FormField
                    control={form.control}
                    name="rememberMe"
                    render={({ field }) => (
                      <div className="flex items-center space-x-2">
                        <Checkbox id="rememberMe" checked={field.value} onCheckedChange={field.onChange} />
                        <label
                          htmlFor="rememberMe"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {t.rememberMe}
                        </label>
                      </div>
                    )}
                  />
                  <Link href="/forgot-password" className="text-sm font-medium text-primary hover:underline">
                    {t.forgotPassword}
                  </Link>
                </div>

                <Button type="submit" className="w-full bg-gradient-to-r from-primary to-tertiary" disabled={isLoading}>
                  {isLoading ? t.signingIn : t.signIn}
                </Button>
              </form>
            </Form>

            <div className="mt-4">
              <Button
                type="button"
                variant="outline"
                className="w-full"
                onClick={() => {
                  form.setValue("email", "admin@example.com")
                  form.setValue("password", "password123")
                  form.handleSubmit(onSubmit)()
                }}
              >
                {t.demoLogin || "Login de Demonstração"}
              </Button>
            </div>

            <div className="mt-6 text-center text-sm">
              {t.dontHaveAccount}{" "}
              <Link href="/register" className="font-medium text-primary hover:underline">
                {t.signUp}
              </Link>
            </div>

            <div className="mt-4 text-center text-xs text-muted-foreground">
              <p>Demo credentials: admin@example.com / password123</p>
            </div>
          </div>

          <div className="mt-8 text-center">
            <p className="text-sm text-muted-foreground">
              {t.bySigningIn}{" "}
              <Link href="#" className="underline underline-offset-4 hover:text-primary">
                {t.termsOfService}
              </Link>{" "}
              {t.and}{" "}
              <Link href="#" className="underline underline-offset-4 hover:text-primary">
                {t.privacyPolicy}
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
