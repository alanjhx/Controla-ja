"use client"
import Navbar from "@/components/navbar"
import HeroSection from "@/components/hero-section"
import TrustBlock from "@/components/trust-block"
import PricingSection from "@/components/pricing-section"
import FeaturesSection from "@/components/features-section"
import Footer from "@/components/footer"

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <main>
        <HeroSection />
        <TrustBlock />
        <FeaturesSection />
        <PricingSection />
      </main>
      <Footer />
    </div>
  )
}
