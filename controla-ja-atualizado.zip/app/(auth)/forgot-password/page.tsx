"use client"

import { useState } from "react"
import Link from "next/link"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { ModeToggle } from "@/components/mode-toggle"
import { Mail, ArrowLeft, CheckCircle } from "lucide-react"
import { useLanguage } from "@/lib/language-context"
import { translations } from "@/lib/translations"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const formSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email address" }),
})

export default function ForgotPasswordPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const { language, setLanguage } = useLanguage()
  const t = translations[language]

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: "",
    },
  })

  function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      setIsSubmitted(true)
    }, 1000)
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5">
      <div className="flex items-center justify-between p-4">
        <Link href="/" className="font-bold text-xl text-primary">
          FINCHECK
        </Link>
        <div className="flex items-center gap-2">
          <Select value={language} onValueChange={setLanguage}>
            <SelectTrigger className="w-[120px] h-8">
              <SelectValue placeholder={t.selectLanguage} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="en">English</SelectItem>
              <SelectItem value="pt">Português</SelectItem>
              <SelectItem value="es">Español</SelectItem>
              <SelectItem value="fr">Français</SelectItem>
            </SelectContent>
          </Select>
          <ModeToggle />
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-md">
          <div className="bg-card rounded-2xl shadow-lg border p-8">
            {!isSubmitted ? (
              <>
                <div className="space-y-2 text-center mb-8">
                  <h1 className="text-3xl font-bold">{t.forgotPassword}</h1>
                  <p className="text-muted-foreground">
                    {t.forgotPasswordDescription ||
                      "Enter your email address and we'll send you a link to reset your password"}
                  </p>
                </div>

                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t.email}</FormLabel>
                          <div className="relative">
                            <Mail className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
                            <FormControl>
                              <Input placeholder="name@example.com" className="pl-10" {...field} />
                            </FormControl>
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button
                      type="submit"
                      className="w-full bg-gradient-to-r from-primary to-tertiary"
                      disabled={isLoading}
                    >
                      {isLoading ? t.sending || "Sending..." : t.sendResetLink || "Send reset link"}
                    </Button>
                  </form>
                </Form>
              </>
            ) : (
              <div className="flex flex-col items-center justify-center py-6">
                <div className="rounded-full bg-green-100 p-3 mb-4">
                  <CheckCircle className="h-8 w-8 text-green-600" />
                </div>
                <h2 className="text-2xl font-bold mb-2">{t.checkYourEmail || "Check your email"}</h2>
                <p className="text-center text-muted-foreground mb-6">
                  {t.resetLinkSent ||
                    "We've sent a password reset link to your email address. Please check your inbox."}
                </p>
                <Button variant="outline" className="w-full">
                  <Link href="/login" className="flex items-center justify-center w-full">
                    <ArrowLeft className="mr-2 h-4 w-4" /> {t.backToLogin || "Back to login"}
                  </Link>
                </Button>
              </div>
            )}

            {!isSubmitted && (
              <div className="mt-6 text-center text-sm">
                {t.rememberPassword || "Remember your password?"}{" "}
                <Link href="/login" className="font-medium text-primary hover:underline">
                  {t.backToLogin || "Back to login"}
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
