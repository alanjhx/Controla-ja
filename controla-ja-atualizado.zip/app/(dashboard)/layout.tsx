import type { ReactNode } from "react"
import { Sidebar } from "@/components/layout/sidebar"
import { MobileNav } from "@/components/layout/mobile-nav"
import { UserNav } from "@/components/layout/user-nav"
import { LanguageProvider } from "@/lib/language-context"
import { AuthProvider } from "@/lib/auth-context"
import { SupabaseProvider } from "@/lib/supabase-context"
import { Toaster } from "@/components/ui/toaster"
import { AIAssistantButton } from "@/components/ai-assistant/ai-assistant"

interface DashboardLayoutProps {
  children: ReactNode
}

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  return (
    <AuthProvider>
      <LanguageProvider>
        <SupabaseProvider>
          <div className="flex min-h-screen flex-col bg-black text-white dark">
            <div className="border-b border-gray-800">
              <div className="flex h-16 items-center px-4 container">
                <div className="md:hidden">
                  <Sidebar />
                </div>
                <div className="ml-auto flex items-center space-x-4">
                  <UserNav />
                </div>
              </div>
            </div>
            <div className="flex-1 flex">
              <div className="hidden md:block">
                <Sidebar />
              </div>
              <main className="flex-1 p-3 md:p-4 lg:p-6">
                <div className="container max-w-[1440px] mx-auto">{children}</div>
              </main>
            </div>
            <MobileNav />
          </div>
          <AIAssistantButton />
          <Toaster />
        </SupabaseProvider>
      </LanguageProvider>
    </AuthProvider>
  )
}
