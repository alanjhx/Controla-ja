"use client"

import { useState } from "react"
import { mockMonthlyIncomeData, mockCategoryDistribution } from "@/lib/mock-data"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { LineChart } from "@/components/dashboard/line-chart"
import { PieChart } from "@/components/dashboard/pie-chart"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Pie,
  Cell,
  PieChart as RechartsPieChart,
  LineChart as RechartsLineChart,
  Line,
} from "recharts"
import { useTheme } from "next-themes"
import { useLanguage } from "@/lib/language-context"
import { translations } from "@/lib/translations"

// Generate monthly expense data
const generateMonthlyExpenseData = () => {
  return [
    { month: "Jan", amount: 1800 },
    { month: "Feb", amount: 2100 },
    { month: "Mar", amount: 1950 },
    { month: "Apr", amount: 2300 },
    { month: "May", amount: 2150 },
    { month: "Jun", amount: 1900 },
    { month: "Jul", amount: 2050 },
    { month: "Aug", amount: 2200 },
    { month: "Sep", amount: 2000 },
    { month: "Oct", amount: 2103 },
    { month: "Nov", amount: 0 },
    { month: "Dec", amount: 0 },
  ]
}

// Generate category comparison data
const generateCategoryComparisonData = () => {
  return [
    { name: "Jan", House: 1200, Food: 800, Investing: 600, Shopping: 500 },
    { name: "Feb", House: 1250, Food: 900, Investing: 700, Shopping: 550 },
    { name: "Mar", House: 1300, Food: 850, Investing: 650, Shopping: 600 },
    { name: "Apr", House: 1350, Food: 950, Investing: 750, Shopping: 650 },
    { name: "May", House: 1400, Food: 1000, Investing: 800, Shopping: 700 },
    { name: "Jun", House: 1450, Food: 950, Investing: 850, Shopping: 750 },
  ]
}

// Generate income vs expense data
const generateIncomeVsExpenseData = () => {
  return [
    { month: "Jan", Income: 3200, Expenses: 1800, Savings: 1400 },
    { month: "Feb", Income: 3400, Expenses: 2100, Savings: 1300 },
    { month: "Mar", Income: 3100, Expenses: 1950, Savings: 1150 },
    { month: "Apr", Income: 3600, Expenses: 2300, Savings: 1300 },
    { month: "May", Income: 4200, Expenses: 2150, Savings: 2050 },
    { month: "Jun", Income: 4500, Expenses: 1900, Savings: 2600 },
    { month: "Jul", Income: 4800, Expenses: 2050, Savings: 2750 },
    { month: "Aug", Income: 4600, Expenses: 2200, Savings: 2400 },
    { month: "Sep", Income: 4900, Expenses: 2000, Savings: 2900 },
    { month: "Oct", Income: 4778, Expenses: 2103, Savings: 2675 },
  ]
}

export default function StatisticsPage() {
  const { theme } = useTheme()
  const isDark = theme === "dark"
  const [period, setPeriod] = useState("year")
  const [chartType, setChartType] = useState("overview")
  const { language } = useLanguage()
  const t = translations[language]

  const monthlyExpenseData = generateMonthlyExpenseData()
  const categoryComparisonData = generateCategoryComparisonData()
  const incomeVsExpenseData = generateIncomeVsExpenseData()

  // Custom tooltip for better interaction
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background border rounded-lg shadow-lg p-3 text-sm">
          <p className="font-medium mb-1">{label}</p>
          {payload.map((entry: any, index: number) => (
            <div key={`item-${index}`} className="flex items-center gap-2 my-1">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }} />
              <span className="text-muted-foreground">{entry.name}:</span>
              <span className="font-medium">${entry.value.toFixed(2)}</span>
            </div>
          ))}
        </div>
      )
    }
    return null
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="text-2xl font-bold tracking-tight">{t.statistics}</h1>
        <div className="flex items-center gap-2">
          <Select defaultValue={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder={t.selectPeriod} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="month">{t.thisMonth}</SelectItem>
              <SelectItem value="quarter">{t.thisQuarter}</SelectItem>
              <SelectItem value="year">{t.thisYear}</SelectItem>
              <SelectItem value="all">{t.allTime}</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs defaultValue={chartType} onValueChange={setChartType} className="space-y-4">
        <TabsList className="grid w-full grid-cols-4 md:grid-cols-4 sm:grid-cols-2">
          <TabsTrigger value="overview">{t.overview}</TabsTrigger>
          <TabsTrigger value="income">{t.income}</TabsTrigger>
          <TabsTrigger value="expenses">{t.expenses}</TabsTrigger>
          <TabsTrigger value="categories">{t.categories}</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>{t.incomeVsExpenses}</CardTitle>
            </CardHeader>
            <CardContent className="px-2 sm:px-6">
              <div className="h-[300px] sm:h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={incomeVsExpenseData} margin={{ top: 20, right: 10, left: 0, bottom: 5 }}>
                    <CartesianGrid
                      strokeDasharray="3 3"
                      vertical={false}
                      stroke={isDark ? "rgba(255, 255, 255, 0.1)" : "rgba(0, 0, 0, 0.1)"}
                    />
                    <XAxis
                      dataKey="month"
                      axisLine={false}
                      tickLine={false}
                      tick={{ fontSize: 12 }}
                      stroke={isDark ? "rgba(255, 255, 255, 0.5)" : "rgba(0, 0, 0, 0.5)"}
                    />
                    <YAxis
                      axisLine={false}
                      tickLine={false}
                      tick={{ fontSize: 12 }}
                      stroke={isDark ? "rgba(255, 255, 255, 0.5)" : "rgba(0, 0, 0, 0.5)"}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend wrapperStyle={{ paddingTop: 10 }} onClick={(e) => console.log(e)} />
                    <Bar
                      dataKey="Income"
                      name={t.income}
                      fill="#3B82F6"
                      radius={[4, 4, 0, 0]}
                      animationDuration={1000}
                      activeBar={{ fill: "#60a5fa", stroke: "#3B82F6", strokeWidth: 2 }}
                    />
                    <Bar
                      dataKey="Expenses"
                      name={t.expenses}
                      fill="#EC4899"
                      radius={[4, 4, 0, 0]}
                      animationDuration={1000}
                      activeBar={{ fill: "#f472b6", stroke: "#EC4899", strokeWidth: 2 }}
                    />
                    <Bar
                      dataKey="Savings"
                      name={t.savings}
                      fill="#8B5CF6"
                      radius={[4, 4, 0, 0]}
                      animationDuration={1000}
                      activeBar={{ fill: "#a78bfa", stroke: "#8B5CF6", strokeWidth: 2 }}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>{t.monthlyIncomeTrend}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[250px] sm:h-[300px]">
                  <LineChart data={mockMonthlyIncomeData} title="" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>{t.expenseDistribution}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[250px] sm:h-[300px]">
                  <PieChart data={mockCategoryDistribution} title="" />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="income" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>{t.incomeTrend}</CardTitle>
            </CardHeader>
            <CardContent className="px-2 sm:px-6">
              <div className="h-[300px] sm:h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsLineChart data={mockMonthlyIncomeData} margin={{ top: 20, right: 10, left: 0, bottom: 5 }}>
                    <CartesianGrid
                      strokeDasharray="3 3"
                      vertical={false}
                      stroke={isDark ? "rgba(255, 255, 255, 0.1)" : "rgba(0, 0, 0, 0.1)"}
                    />
                    <XAxis
                      dataKey="month"
                      axisLine={false}
                      tickLine={false}
                      tick={{ fontSize: 12 }}
                      stroke={isDark ? "rgba(255, 255, 255, 0.5)" : "rgba(0, 0, 0, 0.5)"}
                    />
                    <YAxis
                      axisLine={false}
                      tickLine={false}
                      tick={{ fontSize: 12 }}
                      stroke={isDark ? "rgba(255, 255, 255, 0.5)" : "rgba(0, 0, 0, 0.5)"}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="amount"
                      name={t.income}
                      stroke="#3B82F6"
                      strokeWidth={2}
                      dot={{ r: 4, strokeWidth: 2 }}
                      activeDot={{ r: 6, strokeWidth: 2, stroke: "#3B82F6", fill: "#60a5fa" }}
                      animationDuration={1000}
                    />
                  </RechartsLineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{t.incomeSources}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[250px] sm:h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsPieChart>
                    <Pie
                      data={[
                        { name: t.salary, value: 70 },
                        { name: t.freelance, value: 15 },
                        { name: t.investments, value: 10 },
                        { name: t.other, value: 5 },
                      ]}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={2}
                      dataKey="value"
                      nameKey="name"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      labelLine={false}
                      animationDuration={1000}
                      animationBegin={0}
                    >
                      {[{ color: "#3B82F6" }, { color: "#8B5CF6" }, { color: "#10B981" }, { color: "#F59E0B" }].map(
                        (entry, index) => (
                          <Cell
                            key={`cell-${index}`}
                            fill={entry.color}
                            stroke={isDark ? "#1f2937" : "#ffffff"}
                            strokeWidth={2}
                          />
                        ),
                      )}
                    </Pie>
                    <Tooltip content={<CustomTooltip />} />
                    <Legend layout="vertical" verticalAlign="middle" align="right" iconType="circle" iconSize={8} />
                  </RechartsPieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="expenses" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>{t.expenseTrend}</CardTitle>
            </CardHeader>
            <CardContent className="px-2 sm:px-6">
              <div className="h-[300px] sm:h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsLineChart data={monthlyExpenseData} margin={{ top: 20, right: 10, left: 0, bottom: 5 }}>
                    <CartesianGrid
                      strokeDasharray="3 3"
                      vertical={false}
                      stroke={isDark ? "rgba(255, 255, 255, 0.1)" : "rgba(0, 0, 0, 0.1)"}
                    />
                    <XAxis
                      dataKey="month"
                      axisLine={false}
                      tickLine={false}
                      tick={{ fontSize: 12 }}
                      stroke={isDark ? "rgba(255, 255, 255, 0.5)" : "rgba(0, 0, 0, 0.5)"}
                    />
                    <YAxis
                      axisLine={false}
                      tickLine={false}
                      tick={{ fontSize: 12 }}
                      stroke={isDark ? "rgba(255, 255, 255, 0.5)" : "rgba(0, 0, 0, 0.5)"}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="amount"
                      name={t.expenses}
                      stroke="#EC4899"
                      strokeWidth={2}
                      dot={{ r: 4, strokeWidth: 2 }}
                      activeDot={{ r: 6, strokeWidth: 2, stroke: "#EC4899", fill: "#f472b6" }}
                      animationDuration={1000}
                    />
                  </RechartsLineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{t.expenseCategories}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[250px] sm:h-[300px]">
                <PieChart data={mockCategoryDistribution} title="" centerText="2,103.27" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="categories" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>{t.categoryComparison}</CardTitle>
            </CardHeader>
            <CardContent className="px-2 sm:px-6">
              <div className="h-[300px] sm:h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={categoryComparisonData} margin={{ top: 20, right: 10, left: 0, bottom: 5 }}>
                    <CartesianGrid
                      strokeDasharray="3 3"
                      vertical={false}
                      stroke={isDark ? "rgba(255, 255, 255, 0.1)" : "rgba(0, 0, 0, 0.1)"}
                    />
                    <XAxis
                      dataKey="name"
                      axisLine={false}
                      tickLine={false}
                      tick={{ fontSize: 12 }}
                      stroke={isDark ? "rgba(255, 255, 255, 0.5)" : "rgba(0, 0, 0, 0.5)"}
                    />
                    <YAxis
                      axisLine={false}
                      tickLine={false}
                      tick={{ fontSize: 12 }}
                      stroke={isDark ? "rgba(255, 255, 255, 0.5)" : "rgba(0, 0, 0, 0.5)"}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Bar
                      dataKey="House"
                      name={t.house}
                      fill="#8B5CF6"
                      radius={[4, 4, 0, 0]}
                      animationDuration={1000}
                      activeBar={{ fill: "#a78bfa", stroke: "#8B5CF6", strokeWidth: 2 }}
                    />
                    <Bar
                      dataKey="Food"
                      name={t.food}
                      fill="#EC4899"
                      radius={[4, 4, 0, 0]}
                      animationDuration={1000}
                      activeBar={{ fill: "#f472b6", stroke: "#EC4899", strokeWidth: 2 }}
                    />
                    <Bar
                      dataKey="Investing"
                      name={t.investing}
                      fill="#10B981"
                      radius={[4, 4, 0, 0]}
                      animationDuration={1000}
                      activeBar={{ fill: "#34d399", stroke: "#10B981", strokeWidth: 2 }}
                    />
                    <Bar
                      dataKey="Shopping"
                      name={t.shopping}
                      fill="#3B82F6"
                      radius={[4, 4, 0, 0]}
                      animationDuration={1000}
                      activeBar={{ fill: "#60a5fa", stroke: "#3B82F6", strokeWidth: 2 }}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>{t.topExpenseCategories}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockCategoryDistribution.map((category, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div
                            className="w-3 h-3 rounded-full"
                            style={{
                              backgroundColor:
                                index === 0
                                  ? "#8B5CF6"
                                  : index === 1
                                    ? "#EC4899"
                                    : index === 2
                                      ? "#10B981"
                                      : index === 3
                                        ? "#3B82F6"
                                        : "#F59E0B",
                            }}
                          />
                          <span className="font-medium">{t[category.category.toLowerCase()] || category.category}</span>
                        </div>
                        <span className="font-medium">${((2103 * category.percentage) / 100).toFixed(2)}</span>
                      </div>
                      <div className="h-2 w-full rounded-full bg-muted">
                        <div
                          className="h-2 rounded-full transition-all duration-500 ease-in-out"
                          style={{
                            width: `${category.percentage}%`,
                            backgroundColor:
                              index === 0
                                ? "#8B5CF6"
                                : index === 1
                                  ? "#EC4899"
                                  : index === 2
                                    ? "#10B981"
                                    : index === 3
                                      ? "#3B82F6"
                                      : "#F59E0B",
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>{t.monthlyCategoryGrowth}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{t.house}</span>
                      <span className="text-green-600 dark:text-green-400">+2.5%</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-muted">
                      <div
                        className="h-2 rounded-full bg-purple-500 transition-all duration-500 ease-in-out hover:bg-purple-600"
                        style={{ width: "32%" }}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{t.food}</span>
                      <span className="text-red-600 dark:text-red-400">-1.2%</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-muted">
                      <div
                        className="h-2 rounded-full bg-pink-500 transition-all duration-500 ease-in-out hover:bg-pink-600"
                        style={{ width: "25%" }}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{t.investing}</span>
                      <span className="text-green-600 dark:text-green-400">+5.7%</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-muted">
                      <div
                        className="h-2 rounded-full bg-green-500 transition-all duration-500 ease-in-out hover:bg-green-600"
                        style={{ width: "17%" }}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{t.shopping}</span>
                      <span className="text-red-600 dark:text-red-400">-3.1%</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-muted">
                      <div
                        className="h-2 rounded-full bg-blue-500 transition-all duration-500 ease-in-out hover:bg-blue-600"
                        style={{ width: "16%" }}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{t.books}</span>
                      <span className="text-green-600 dark:text-green-400">+0.8%</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-muted">
                      <div
                        className="h-2 rounded-full bg-amber-500 transition-all duration-500 ease-in-out hover:bg-amber-600"
                        style={{ width: "10%" }}
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
