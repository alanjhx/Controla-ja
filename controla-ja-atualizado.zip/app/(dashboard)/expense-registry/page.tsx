"use client"

import { useState, useEffect } from "react"
import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Skeleton } from "@/components/ui/skeleton"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { CalendarIcon, Plus, Search, Filter, ArrowUpDown, Trash2, Edit } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { useSupabase } from "@/lib/supabase-context"
import { cn } from "@/lib/utils"
import { useLanguage } from "@/lib/language-context"
import { translations } from "@/lib/translations"
import { formatCurrency } from "@/lib/currency-formatter"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

function ExpenseRegistrySkeleton() {
  return (
    <div className="space-y-4">
      <Skeleton className="h-10 w-[250px]" />
      <Skeleton className="h-[500px] rounded-lg" />
    </div>
  )
}

const expenseFormSchema = z.object({
  description: z.string().min(1, { message: "Description is required" }),
  amount: z.coerce.number().positive({ message: "Amount must be positive" }),
  date: z.date(),
  categoryId: z.string().min(1, { message: "Category is required" }),
  type: z.enum(["income", "expense"]),
  paymentMethod: z.string().min(1, { message: "Payment method is required" }),
  notes: z.string().optional(),
  recurrence: z.enum(["one-time", "weekly", "monthly", "yearly"]),
  tags: z.array(z.string()).optional(),
})

export default function ExpenseRegistryPage() {
  const { language, currency } = useLanguage()
  const t = translations[language]
  const [isLoading, setIsLoading] = useState(false)
  const [filter, setFilter] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingTransaction, setEditingTransaction] = useState<any>(null)
  const [filteredTransactions, setFilteredTransactions] = useState<any[]>([])
  const [dateFilter, setDateFilter] = useState<{ from?: Date; to?: Date }>({})
  const [categoryFilter, setCategoryFilter] = useState<string>("all-categories")
  const [amountFilter, setAmountFilter] = useState<{ min?: number; max?: number }>({})
  const [filterDialogOpen, setFilterDialogOpen] = useState(false)
  const [tags, setTags] = useState<string[]>([])
  const [newTag, setNewTag] = useState("")
  const { toast } = useToast()

  // Use Supabase context for global state
  const {
    transactions,
    categories,
    cards,
    addTransaction,
    updateTransaction,
    deleteTransaction,
    isLoading: isDataLoading,
  } = useSupabase()

  const form = useForm<z.infer<typeof expenseFormSchema>>({
    resolver: zodResolver(expenseFormSchema),
    defaultValues: {
      description: "",
      amount: 0,
      date: new Date(),
      categoryId: "",
      type: "expense",
      paymentMethod: "",
      notes: "",
      recurrence: "one-time",
      tags: [],
    },
  })

  // Apply filters whenever transactions or filter criteria change
  useEffect(() => {
    filterTransactions(filter, searchTerm, dateFilter, categoryFilter, amountFilter)
  }, [transactions, filter, searchTerm, dateFilter, categoryFilter, amountFilter])

  const handleFilterChange = (value: string) => {
    setFilter(value)
  }

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const term = e.target.value
    setSearchTerm(term)
  }

  const filterTransactions = (
    filterValue: string,
    term: string,
    dates: { from?: Date; to?: Date },
    category: string,
    amounts: { min?: number; max?: number },
  ) => {
    let filtered = [...transactions]

    // Apply type filter
    if (filterValue !== "all") {
      filtered = filtered.filter((transaction) => transaction.type === filterValue)
    }

    // Apply search term
    if (term) {
      filtered = filtered.filter((transaction) => transaction.description.toLowerCase().includes(term.toLowerCase()))
    }

    // Apply date filter
    if (dates.from) {
      filtered = filtered.filter((transaction) => new Date(transaction.date) >= dates.from!)
    }
    if (dates.to) {
      filtered = filtered.filter((transaction) => new Date(transaction.date) <= dates.to!)
    }

    // Apply category filter
    if (category && category !== "all-categories") {
      filtered = filtered.filter((transaction) => transaction.categoryId === category)
    }

    // Apply amount filter
    if (amounts.min !== undefined) {
      filtered = filtered.filter((transaction) => transaction.amount >= amounts.min!)
    }
    if (amounts.max !== undefined) {
      filtered = filtered.filter((transaction) => transaction.amount <= amounts.max!)
    }

    setFilteredTransactions(filtered)
  }

  const handleAddTag = () => {
    if (newTag.trim() && !tags.includes(newTag.trim())) {
      const updatedTags = [...tags, newTag.trim()]
      setTags(updatedTags)
      form.setValue("tags", updatedTags)
      setNewTag("")
    }
  }

  const handleRemoveTag = (tagToRemove: string) => {
    const updatedTags = tags.filter((tag) => tag !== tagToRemove)
    setTags(updatedTags)
    form.setValue("tags", updatedTags)
  }

  const onSubmit = async (values: z.infer<typeof expenseFormSchema>) => {
    setIsLoading(true)

    try {
      // Create transaction object from form values
      const transactionData = {
        description: values.description,
        amount: values.amount,
        date: values.date.toISOString().split("T")[0],
        type: values.type,
        categoryId: values.categoryId,
        cardId: values.paymentMethod !== "cash" ? values.paymentMethod : undefined,
        notes: values.notes,
        recurrence: values.recurrence,
        tags: values.tags,
      }

      if (editingTransaction) {
        // Update existing transaction
        await updateTransaction(editingTransaction.id, transactionData)
        toast({
          title: "Transação atualizada",
          description: "A transação foi atualizada com sucesso.",
        })
      } else {
        // Add new transaction
        await addTransaction(transactionData)
        toast({
          title: "Transação adicionada",
          description: "A nova transação foi adicionada com sucesso.",
        })
      }

      setDialogOpen(false)
      form.reset()
      setEditingTransaction(null)
      setTags([])
    } catch (error) {
      console.error("Error submitting transaction:", error)
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao processar a transação. Tente novamente.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleEdit = (transaction: any) => {
    setEditingTransaction(transaction)

    // Set form values
    form.reset({
      description: transaction.description,
      amount: transaction.amount,
      date: new Date(transaction.date),
      categoryId: transaction.categoryId,
      type: transaction.type,
      paymentMethod: transaction.cardId || "cash",
      notes: transaction.notes || "",
      recurrence: transaction.recurrence || "one-time",
      tags: transaction.tags || [],
    })

    setTags(transaction.tags || [])
    setDialogOpen(true)
  }

  const handleDelete = async (id: string) => {
    try {
      await deleteTransaction(id)
      toast({
        title: "Transação excluída",
        description: "A transação foi excluída com sucesso.",
      })
    } catch (error) {
      console.error("Error deleting transaction:", error)
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao excluir a transação. Tente novamente.",
        variant: "destructive",
      })
    }
  }

  const handleApplyFilters = () => {
    filterTransactions(filter, searchTerm, dateFilter, categoryFilter, amountFilter)
    setFilterDialogOpen(false)
  }

  const handleResetFilters = () => {
    setDateFilter({})
    setCategoryFilter("all-categories")
    setAmountFilter({})
    filterTransactions(filter, searchTerm, {}, "all-categories", {})
    setFilterDialogOpen(false)
  }

  const expenseCategories = categories.filter((category) => category.type === "expense")
  const incomeCategories = categories.filter((category) => category.type === "income")

  if (isDataLoading) {
    return <ExpenseRegistrySkeleton />
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="text-2xl font-bold tracking-tight">{t.expenseRegistry}</h1>
        <Dialog
          open={dialogOpen}
          onOpenChange={(open) => {
            setDialogOpen(open)
            if (!open) {
              form.reset()
              setEditingTransaction(null)
              setTags([])
            }
          }}
        >
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" /> {t.addTransaction}
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>{editingTransaction ? t.editTransaction : t.addTransaction}</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t.type}</FormLabel>
                      <RadioGroup onValueChange={field.onChange} defaultValue={field.value} className="flex space-x-4">
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="expense" id="expense" />
                          <Label htmlFor="expense" className="text-red-500">
                            {t.expense}
                          </Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="income" id="income" />
                          <Label htmlFor="income" className="text-green-500">
                            {t.income}
                          </Label>
                        </div>
                      </RadioGroup>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t.description}</FormLabel>
                        <FormControl>
                          <Input placeholder={t.description} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="amount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t.amount}</FormLabel>
                        <FormControl>
                          <Input type="number" step="0.01" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="date"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>{t.date}</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant={"outline"}
                                className={cn(
                                  "w-full pl-3 text-left font-normal",
                                  !field.value && "text-muted-foreground",
                                )}
                              >
                                {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="categoryId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t.category}</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={
                            field.value ||
                            (form.watch("type") === "expense" ? expenseCategories[0]?.id : incomeCategories[0]?.id) ||
                            ""
                          }
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder={`${t.select} ${t.category}`} />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {form.watch("type") === "expense"
                              ? expenseCategories.map((category) => (
                                  <SelectItem key={category.id} value={category.id}>
                                    {t[category.name.toLowerCase()] || category.name}
                                  </SelectItem>
                                ))
                              : incomeCategories.map((category) => (
                                  <SelectItem key={category.id} value={category.id}>
                                    {t[category.name.toLowerCase()] || category.name}
                                  </SelectItem>
                                ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="paymentMethod"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t.paymentMethod}</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value || "cash"}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder={`${t.select} ${t.paymentMethod}`} />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="cash">{t.cash || "Cash"}</SelectItem>
                            {cards.map((card) => (
                              <SelectItem key={card.id} value={card.id}>
                                {card.name} ({t[card.type] || card.type})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="recurrence"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t.recurrence || "Recurrence"}</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder={t.selectRecurrence || "Select recurrence"} />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="one-time">{t.oneTime || "One-time"}</SelectItem>
                            <SelectItem value="weekly">{t.weekly || "Weekly"}</SelectItem>
                            <SelectItem value="monthly">{t.monthly || "Monthly"}</SelectItem>
                            <SelectItem value="yearly">{t.yearly || "Yearly"}</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t.notes || "Notes"}</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder={t.notesPlaceholder || "Add any additional details here..."}
                          className="resize-none"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="tags"
                  render={() => (
                    <FormItem>
                      <FormLabel>{t.tags || "Tags"}</FormLabel>
                      <div className="flex flex-wrap gap-2 mb-2">
                        {tags.map((tag) => (
                          <Badge key={tag} variant="secondary" className="flex items-center gap-1">
                            {tag}
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              className="h-4 w-4 p-0 hover:bg-transparent"
                              onClick={() => handleRemoveTag(tag)}
                            >
                              <Trash2 className="h-3 w-3" />
                              <span className="sr-only">Remove</span>
                            </Button>
                          </Badge>
                        ))}
                      </div>
                      <div className="flex gap-2">
                        <Input
                          value={newTag}
                          onChange={(e) => setNewTag(e.target.value)}
                          placeholder={t.addTag || "Add a tag"}
                          className="flex-1"
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              e.preventDefault()
                              handleAddTag()
                            }
                          }}
                        />
                        <Button type="button" variant="outline" size="sm" onClick={handleAddTag}>
                          <Plus className="h-4 w-4" />
                          <span className="sr-only">Add</span>
                        </Button>
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                    {t.cancel}
                  </Button>
                  <Button type="submit" disabled={isLoading}>
                    {isLoading ? t.saving : t.save}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader className="p-4">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <Tabs defaultValue={filter} onValueChange={handleFilterChange} className="w-full sm:w-auto">
              <TabsList>
                <TabsTrigger value="all">{t.all}</TabsTrigger>
                <TabsTrigger value="income">{t.income}</TabsTrigger>
                <TabsTrigger value="expense">{t.expense}</TabsTrigger>
              </TabsList>
            </Tabs>
            <div className="flex flex-1 items-center gap-2 sm:max-w-[400px]">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder={t.searchTransactions}
                  className="pl-8"
                  value={searchTerm}
                  onChange={handleSearch}
                />
              </div>

              <Dialog open={filterDialogOpen} onOpenChange={setFilterDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="icon" className="shrink-0">
                    <Filter className="h-4 w-4" />
                    <span className="sr-only">{t.filter}</span>
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>{t.filterTransactions || "Filter Transactions"}</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <h3 className="text-sm font-medium">{t.dateRange || "Date Range"}</h3>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="space-y-1">
                          <Label htmlFor="from">{t.from || "From"}</Label>
                          <Popover>
                            <PopoverTrigger asChild>
                              <Button
                                id="from"
                                variant={"outline"}
                                className={cn(
                                  "w-full justify-start text-left font-normal",
                                  !dateFilter.from && "text-muted-foreground",
                                )}
                              >
                                {dateFilter.from ? (
                                  format(dateFilter.from, "PPP")
                                ) : (
                                  <span>{t.selectDate || "Select date"}</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar
                                mode="single"
                                selected={dateFilter.from}
                                onSelect={(date) => setDateFilter((prev) => ({ ...prev, from: date }))}
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                        </div>
                        <div className="space-y-1">
                          <Label htmlFor="to">{t.to || "To"}</Label>
                          <Popover>
                            <PopoverTrigger asChild>
                              <Button
                                id="to"
                                variant={"outline"}
                                className={cn(
                                  "w-full justify-start text-left font-normal",
                                  !dateFilter.to && "text-muted-foreground",
                                )}
                              >
                                {dateFilter.to ? (
                                  format(dateFilter.to, "PPP")
                                ) : (
                                  <span>{t.selectDate || "Select date"}</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar
                                mode="single"
                                selected={dateFilter.to}
                                onSelect={(date) => setDateFilter((prev) => ({ ...prev, to: date }))}
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <h3 className="text-sm font-medium">{t.category}</h3>
                      <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                        <SelectTrigger>
                          <SelectValue placeholder={t.allCategories || "All categories"} />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all-categories">{t.allCategories || "All categories"}</SelectItem>
                          {categories.map((category) => (
                            <SelectItem key={category.id} value={category.id}>
                              {t[category.name.toLowerCase()] || category.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <h3 className="text-sm font-medium">{t.amountRange || "Amount Range"}</h3>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="space-y-1">
                          <Label htmlFor="min">{t.min || "Min"}</Label>
                          <Input
                            id="min"
                            type="number"
                            placeholder="0"
                            value={amountFilter.min || ""}
                            onChange={(e) =>
                              setAmountFilter((prev) => ({
                                ...prev,
                                min: e.target.value ? Number(e.target.value) : undefined,
                              }))
                            }
                          />
                        </div>
                        <div className="space-y-1">
                          <Label htmlFor="max">{t.max || "Max"}</Label>
                          <Input
                            id="max"
                            type="number"
                            placeholder="9999"
                            value={amountFilter.max || ""}
                            onChange={(e) =>
                              setAmountFilter((prev) => ({
                                ...prev,
                                max: e.target.value ? Number(e.target.value) : undefined,
                              }))
                            }
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={handleResetFilters}>
                      {t.resetFilters || "Reset Filters"}
                    </Button>
                    <Button onClick={handleApplyFilters}>{t.applyFilters || "Apply Filters"}</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>

              <Button variant="outline" size="icon" className="shrink-0">
                <ArrowUpDown className="h-4 w-4" />
                <span className="sr-only">{t.sort}</span>
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t.description}</TableHead>
                <TableHead>{t.category}</TableHead>
                <TableHead>{t.date}</TableHead>
                <TableHead className="text-right">{t.amount}</TableHead>
                <TableHead className="text-right">{t.actions || "Actions"}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTransactions.length > 0 ? (
                filteredTransactions.map((transaction) => {
                  const category = categories.find((c) => c.id === transaction.categoryId)
                  return (
                    <TableRow key={transaction.id}>
                      <TableCell className="font-medium">{transaction.description}</TableCell>
                      <TableCell>
                        <div
                          className={cn(
                            "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium",
                            transaction.type === "income"
                              ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                              : "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300",
                          )}
                        >
                          {t[category?.name.toLowerCase() || ""] || category?.name}
                        </div>
                        {transaction.tags && transaction.tags.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-1">
                            {transaction.tags.slice(0, 2).map((tag: string) => (
                              <Badge key={tag} variant="outline" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                            {transaction.tags.length > 2 && (
                              <Badge variant="outline" className="text-xs">
                                +{transaction.tags.length - 2}
                              </Badge>
                            )}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>{format(new Date(transaction.date), "dd.MM.yyyy")}</TableCell>
                      <TableCell
                        className={cn(
                          "text-right font-medium",
                          transaction.type === "income"
                            ? "text-green-600 dark:text-green-400"
                            : "text-red-600 dark:text-red-400",
                        )}
                      >
                        {transaction.type === "income" ? "+" : "-"}
                        {formatCurrency(transaction.amount, currency)}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="icon" onClick={() => handleEdit(transaction)}>
                            <Edit className="h-4 w-4" />
                            <span className="sr-only">{t.edit}</span>
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => handleDelete(transaction.id)}>
                            <Trash2 className="h-4 w-4" />
                            <span className="sr-only">{t.delete}</span>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })
              ) : (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                    {t.noTransactionsFound || "No transactions found"}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
