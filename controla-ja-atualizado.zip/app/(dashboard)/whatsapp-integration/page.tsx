"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Send, FileText, HelpCircle } from "lucide-react"
import { useLanguage } from "@/lib/language-context"
import { translations } from "@/lib/translations"
import { WhatsAppConnector } from "@/components/whatsapp/whatsapp-connector"

export default function WhatsAppIntegrationPage() {
  const [activeTab, setActiveTab] = useState("connect")
  const [isWhatsappConnected, setIsWhatsappConnected] = useState(false)
  const [notificationsEnabled, setNotificationsEnabled] = useState(true)
  const [transactionAlerts, setTransactionAlerts] = useState(true)
  const [weeklyReports, setWeeklyReports] = useState(true)
  const { language } = useLanguage()
  const t = translations[language]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Integração com WhatsApp</h1>
        <p className="text-muted-foreground">Gerencie suas finanças diretamente pelo WhatsApp.</p>
      </div>

      <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="connect">Conectar</TabsTrigger>
          <TabsTrigger value="commands">Comandos</TabsTrigger>
          <TabsTrigger value="settings">Configurações</TabsTrigger>
          <TabsTrigger value="how-to">Como Usar</TabsTrigger>
        </TabsList>

        <TabsContent value="connect" className="space-y-4">
          <WhatsAppConnector onStatusChange={(connected) => setIsWhatsappConnected(connected)} />
        </TabsContent>

        <TabsContent value="commands" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Comandos do WhatsApp</CardTitle>
              <CardDescription>Use estes comandos para gerenciar suas finanças pelo WhatsApp.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="flex items-start gap-3 p-3 border rounded-lg">
                  <Send className="h-5 w-5 text-primary mt-0.5" />
                  <div>
                    <h4 className="font-medium">ajuda</h4>
                    <p className="text-sm text-muted-foreground">Exibe a lista de comandos disponíveis</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 border rounded-lg">
                  <Send className="h-5 w-5 text-primary mt-0.5" />
                  <div>
                    <h4 className="font-medium">resumo</h4>
                    <p className="text-sm text-muted-foreground">Exibe um resumo da sua situação financeira atual</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 border rounded-lg">
                  <Send className="h-5 w-5 text-primary mt-0.5" />
                  <div>
                    <h4 className="font-medium">receita [valor] [descrição]</h4>
                    <p className="text-sm text-muted-foreground">
                      Registra uma nova receita. Exemplo: receita 1500 Salário
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 border rounded-lg">
                  <Send className="h-5 w-5 text-primary mt-0.5" />
                  <div>
                    <h4 className="font-medium">despesa [valor] [descrição]</h4>
                    <p className="text-sm text-muted-foreground">
                      Registra uma nova despesa. Exemplo: despesa 50.90 Supermercado
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 border rounded-lg">
                  <Send className="h-5 w-5 text-primary mt-0.5" />
                  <div>
                    <h4 className="font-medium">transações</h4>
                    <p className="text-sm text-muted-foreground">Lista as últimas transações registradas</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 border rounded-lg">
                  <Send className="h-5 w-5 text-primary mt-0.5" />
                  <div>
                    <h4 className="font-medium">relatório</h4>
                    <p className="text-sm text-muted-foreground">
                      Envia um relatório financeiro detalhado para seu e-mail
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" className="gap-2">
                <FileText className="h-4 w-4" /> Baixar guia completo
              </Button>
              <Button variant="outline" className="gap-2">
                <HelpCircle className="h-4 w-4" /> Suporte
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Configurações do WhatsApp</CardTitle>
              <CardDescription>Personalize como você recebe informações pelo WhatsApp.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="notifications">Notificações</Label>
                  <p className="text-sm text-muted-foreground">Receba notificações pelo WhatsApp</p>
                </div>
                <Switch
                  id="notifications"
                  checked={notificationsEnabled}
                  onCheckedChange={setNotificationsEnabled}
                  disabled={!isWhatsappConnected}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="transaction-alerts">Alertas de transações</Label>
                  <p className="text-sm text-muted-foreground">
                    Receba alertas quando novas transações forem registradas
                  </p>
                </div>
                <Switch
                  id="transaction-alerts"
                  checked={transactionAlerts}
                  onCheckedChange={setTransactionAlerts}
                  disabled={!notificationsEnabled || !isWhatsappConnected}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="weekly-reports">Relatórios semanais</Label>
                  <p className="text-sm text-muted-foreground">
                    Receba um relatório semanal com o resumo das suas finanças
                  </p>
                </div>
                <Switch
                  id="weekly-reports"
                  checked={weeklyReports}
                  onCheckedChange={setWeeklyReports}
                  disabled={!notificationsEnabled || !isWhatsappConnected}
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full" disabled={!isWhatsappConnected}>
                Salvar configurações
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="how-to" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Como usar a integração com WhatsApp</CardTitle>
              <CardDescription>Siga estes passos para começar a usar o FinCheck pelo WhatsApp.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-start gap-4 p-4 border rounded-lg">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary">
                    1
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Conecte seu WhatsApp</h3>
                    <p className="text-sm text-muted-foreground">
                      Na aba "Conectar", insira seu número de telefone ou escaneie o QR code para vincular seu WhatsApp
                      ao FinCheck.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 border rounded-lg">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary">
                    2
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Adicione o número do FinCheck aos seus contatos</h3>
                    <p className="text-sm text-muted-foreground">
                      Adicione o número +55 (11) 91234-5678 à sua lista de contatos do WhatsApp com o nome "FinCheck".
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 border rounded-lg">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary">
                    3
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Envie "ajuda" para começar</h3>
                    <p className="text-sm text-muted-foreground">
                      Envie a mensagem "ajuda" para o contato FinCheck para receber a lista de comandos disponíveis.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 border rounded-lg">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary">
                    4
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Comece a registrar suas finanças</h3>
                    <p className="text-sm text-muted-foreground">
                      Use os comandos para registrar receitas, despesas e consultar seu saldo diretamente pelo WhatsApp.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
