"use client"

import { useState, useEffect, useRef } from "react"
import { mockDebts } from "@/lib/mock-data"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Skeleton } from "@/components/ui/skeleton"
import {
  Plus,
  FileText,
  CheckCircle,
  AlertTriangle,
  TrendingUp,
  Trash2,
  Edit,
  Share2,
  Printer,
  Mail,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { useLanguage } from "@/lib/language-context"
import { translations } from "@/lib/translations"
import { formatCurrency } from "@/lib/currency-formatter"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { CalendarIcon } from "lucide-react"
import { format } from "date-fns"
import {
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Legend,
  Tooltip,
  BarChart as RechartsBarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  LineChart,
  Line,
} from "recharts"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

function DebtPlannerSkeleton() {
  return (
    <div className="space-y-4">
      <Skeleton className="h-10 w-[250px]" />
      <div className="grid gap-4 md:grid-cols-2">
        {Array(2)
          .fill(0)
          .map((_, i) => (
            <Skeleton key={i} className="h-[200px] rounded-lg" />
          ))}
      </div>
    </div>
  )
}

function getStatusIcon(status: string) {
  switch (status) {
    case "active":
      return <AlertTriangle className="h-5 w-5 text-amber-500" />
    case "negotiating":
      return <FileText className="h-5 w-5 text-blue-500" />
    case "paid":
      return <CheckCircle className="h-5 w-5 text-green-500" />
    default:
      return <AlertTriangle className="h-5 w-5 text-amber-500" />
  }
}

function getStatusColor(status: string) {
  switch (status) {
    case "active":
      return "text-amber-500"
    case "negotiating":
      return "text-blue-500"
    case "paid":
      return "text-green-500"
    default:
      return "text-amber-500"
  }
}

const debtFormSchema = z.object({
  creditor: z.string().min(1, { message: "Creditor is required" }),
  amount: z.coerce.number().positive({ message: "Amount must be positive" }),
  description: z.string().min(1, { message: "Description is required" }),
  status: z.enum(["active", "negotiating", "paid"]),
  dueDate: z.date().optional(),
  installments: z.coerce.number().int().positive().optional(),
  installmentAmount: z.coerce.number().positive().optional(),
  interestRate: z.coerce.number().min(0).optional(),
  notes: z.string().optional(),
})

export default function DebtPlannerPage() {
  const { language, currency } = useLanguage()
  const t = translations[language]
  const [isLoading, setIsLoading] = useState(false)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [aiPlanDialogOpen, setAiPlanDialogOpen] = useState(false)
  const [debts, setDebts] = useState(mockDebts)
  const [activeTab, setActiveTab] = useState("all")
  const [aiPlanGenerated, setAiPlanGenerated] = useState(false)
  const [editingDebt, setEditingDebt] = useState<any>(null)
  const [aiPlanData, setAiPlanData] = useState<any>(null)
  const [shareDialogOpen, setShareDialogOpen] = useState(false)
  const { toast } = useToast()
  const printRef = useRef<HTMLDivElement>(null)

  // Auto-detect language and apply translations
  useEffect(() => {
    // This is already handled by the LanguageProvider in lib/language-context.tsx
    // The provider detects browser language on mount
  }, [])

  const form = useForm<z.infer<typeof debtFormSchema>>({
    resolver: zodResolver(debtFormSchema),
    defaultValues: {
      creditor: "",
      amount: 0,
      description: "",
      status: "active",
      dueDate: undefined,
      installments: undefined,
      installmentAmount: undefined,
      interestRate: undefined,
      notes: "",
    },
  })

  const onSubmit = (values: z.infer<typeof debtFormSchema>) => {
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      // Add new debt to the list
      const newDebt = {
        id: editingDebt ? editingDebt.id : `debt-${Date.now()}`,
        creditor: values.creditor,
        amount: values.amount,
        description: values.description,
        status: values.status,
        dueDate: values.dueDate ? values.dueDate.toISOString().split("T")[0] : undefined,
        installments: values.installments,
        installmentAmount: values.installmentAmount,
        interestRate: values.interestRate,
        notes: values.notes,
      }

      if (editingDebt) {
        // Update existing debt
        setDebts((prev) => prev.map((debt) => (debt.id === editingDebt.id ? newDebt : debt)))
      } else {
        // Add new debt
        setDebts([...debts, newDebt])
      }

      setIsLoading(false)
      setDialogOpen(false)
      form.reset()
      setEditingDebt(null)

      toast({
        title: editingDebt ? "Dívida atualizada" : "Dívida adicionada",
        description: editingDebt ? "A dívida foi atualizada com sucesso." : "A nova dívida foi adicionada com sucesso.",
      })
    }, 1000)
  }

  const handleEdit = (debt: any) => {
    setEditingDebt(debt)

    // Set form values
    form.reset({
      creditor: debt.creditor,
      amount: debt.amount,
      description: debt.description,
      status: debt.status,
      dueDate: debt.dueDate ? new Date(debt.dueDate) : undefined,
      installments: debt.installments,
      installmentAmount: debt.installmentAmount,
      interestRate: debt.interestRate,
      notes: debt.notes,
    })

    setDialogOpen(true)
  }

  const handleDelete = (id: string) => {
    // Simulate API call
    setDebts((prev) => prev.filter((debt) => debt.id !== id))
    toast({
      title: "Dívida excluída",
      description: "A dívida foi excluída com sucesso.",
    })
  }

  const generateAiPlan = () => {
    setIsLoading(true)

    // Simulate AI processing
    setTimeout(() => {
      // Generate AI plan data based on current debts
      const totalDebt = debts.reduce((sum, debt) => sum + debt.amount, 0)
      const monthlyPayment = Math.round(totalDebt / 12)
      const monthsToPayoff = Math.ceil(totalDebt / monthlyPayment)

      // Generate debt distribution data
      const debtDistributionData = [
        {
          name: t.active || "Ativa",
          value: debts.filter((d) => d.status === "active").reduce((sum, d) => sum + d.amount, 0),
        },
        {
          name: t.negotiating || "Em negociação",
          value: debts.filter((d) => d.status === "negotiating").reduce((sum, d) => sum + d.amount, 0),
        },
        {
          name: t.paid || "Paga",
          value: debts.filter((d) => d.status === "paid").reduce((sum, d) => sum + d.amount, 0),
        },
      ].filter((item) => item.value > 0)

      // Generate payment plan data
      const paymentPlanData = Array(12)
        .fill(0)
        .map((_, i) => {
          const month = new Date()
          month.setMonth(month.getMonth() + i)
          return {
            month: month.toLocaleString(language === "en" ? "en-US" : "pt-BR", { month: "short" }),
            Planejado: monthlyPayment,
            Real: i < 3 ? monthlyPayment : i < 5 ? Math.round(monthlyPayment * 0.8) : 0,
          }
        })

      // Generate debt evolution data
      const debtEvolutionData = Array(12)
        .fill(0)
        .map((_, i) => {
          const month = new Date()
          month.setMonth(month.getMonth() + i)
          const remainingDebt = Math.max(0, totalDebt - monthlyPayment * i)
          const totalPaid = Math.min(totalDebt, monthlyPayment * i)

          return {
            month: month.toLocaleString(language === "en" ? "en-US" : "pt-BR", { month: "short" }),
            Dívida: remainingDebt,
            Pago: totalPaid,
          }
        })

      // Generate recommendations based on debts
      const recommendations = [
        debts.length > 0
          ? `${t.recommendation1 || "Foque em pagar primeiro a dívida com maior taxa de juros"} (${debts[0].creditor}).`
          : t.recommendation1 || "Foque em pagar primeiro a dívida com maior taxa de juros.",
        t.recommendation2 || "Considere consolidar suas dívidas de cartão de crédito para reduzir as taxas de juros.",
        t.recommendation3 || "Configure pagamentos automáticos para garantir que nunca perca um pagamento.",
        t.recommendation4 || "Crie um fundo de emergência para evitar novas dívidas em caso de despesas inesperadas.",
      ]

      setAiPlanData({
        totalDebt,
        monthlyPayment,
        monthsToPayoff,
        debtDistributionData,
        paymentPlanData,
        debtEvolutionData,
        recommendations,
      })

      setIsLoading(false)
      setAiPlanGenerated(true)
    }, 2000)
  }

  const handlePrintPDF = () => {
    if (printRef.current) {
      const printWindow = window.open("", "_blank")
      if (printWindow) {
        printWindow.document.write(`
          <html>
            <head>
              <title>Plano de Pagamento de Dívidas</title>
              <style>
                body { font-family: Arial, sans-serif; padding: 20px; }
                h1 { color: #333; }
                .section { margin-bottom: 20px; }
                .card { border: 1px solid #ddd; border-radius: 8px; padding: 15px; margin-bottom: 15px; }
                .summary { display: flex; justify-content: space-between; }
                .summary-item { text-align: center; }
                .recommendations li { margin-bottom: 10px; }
                table { width: 100%; border-collapse: collapse; }
                th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                th { background-color: #f2f2f2; }
              </style>
            </head>
            <body>
              <h1>Plano de Pagamento de Dívidas - FinCheck</h1>
              
              <div class="section">
                <h2>Resumo</h2>
                <div class="summary">
                  <div class="summary-item">
                    <h3>Dívida Total</h3>
                    <p>${formatCurrency(aiPlanData.totalDebt, currency)}</p>
                  </div>
                  <div class="summary-item">
                    <h3>Pagamento Mensal</h3>
                    <p>${formatCurrency(aiPlanData.monthlyPayment, currency)}</p>
                  </div>
                  <div class="summary-item">
                    <h3>Tempo para Quitação</h3>
                    <p>${aiPlanData.monthsToPayoff} meses</p>
                  </div>
                </div>
              </div>
              
              <div class="section">
                <h2>Recomendações</h2>
                <ul class="recommendations">
                  ${aiPlanData.recommendations.map((rec: string) => `<li>${rec}</li>`).join("")}
                </ul>
              </div>
              
              <div class="section">
                <h2>Detalhes das Dívidas</h2>
                <table>
                  <tr>
                    <th>Credor</th>
                    <th>Descrição</th>
                    <th>Valor</th>
                    <th>Status</th>
                    <th>Taxa de Juros</th>
                  </tr>
                  ${debts
                    .map(
                      (debt) => `
                    <tr>
                      <td>${debt.creditor}</td>
                      <td>${debt.description}</td>
                      <td>${formatCurrency(debt.amount, currency)}</td>
                      <td>${debt.status === "active" ? "Ativa" : debt.status === "negotiating" ? "Em negociação" : "Paga"}</td>
                      <td>${debt.interestRate ? debt.interestRate + "%" : "N/A"}</td>
                    </tr>
                  `,
                    )
                    .join("")}
                </table>
              </div>
              
              <div class="section">
                <h2>Plano de Pagamento</h2>
                <p>Pagamento mensal recomendado: ${formatCurrency(aiPlanData.monthlyPayment, currency)}</p>
                <p>Tempo estimado para quitação total: ${aiPlanData.monthsToPayoff} meses</p>
              </div>
              
              <footer>
                <p>Gerado por FinCheck em ${new Date().toLocaleDateString()}</p>
              </footer>
            </body>
          </html>
        `)
        printWindow.document.close()
        printWindow.print()
      }
    }
  }

  const handleShareByEmail = () => {
    // In a real app, this would send the plan via email
    toast({
      title: "Plano enviado por email",
      description: "O plano de pagamento foi enviado para seu email cadastrado.",
    })
    setShareDialogOpen(false)
  }

  const handleShareByWhatsApp = () => {
    // In a real app, this would share via WhatsApp
    toast({
      title: "Plano compartilhado via WhatsApp",
      description: "O link para o plano de pagamento foi enviado via WhatsApp.",
    })
    setShareDialogOpen(false)
  }

  const filteredDebts = activeTab === "all" ? debts : debts.filter((debt) => debt.status === activeTab)

  // Data for debt distribution chart
  const debtDistributionData = [
    {
      name: t.active || "Ativa",
      value: debts.filter((d) => d.status === "active").reduce((sum, d) => sum + d.amount, 0),
    },
    {
      name: t.negotiating || "Em negociação",
      value: debts.filter((d) => d.status === "negotiating").reduce((sum, d) => sum + d.amount, 0),
    },
    { name: t.paid || "Paga", value: debts.filter((d) => d.status === "paid").reduce((sum, d) => sum + d.amount, 0) },
  ].filter((item) => item.value > 0)

  const COLORS = ["#F59E0B", "#3B82F6", "#10B981"]

  // Data for debt evolution chart
  const debtEvolutionData = [
    { month: "Jan", Dívida: 5000, Pago: 450 },
    { month: "Fev", Dívida: 4550, Pago: 900 },
    { month: "Mar", Dívida: 4100, Pago: 1350 },
    { month: "Abr", Dívida: 3650, Pago: 1750 },
    { month: "Mai", Dívida: 3300, Pago: 2100 },
    { month: "Jun", Dívida: 3300, Pago: 2100 },
    { month: "Jul", Dívida: 3300, Pago: 2100 },
    { month: "Ago", Dívida: 3300, Pago: 2100 },
    { month: "Set", Dívida: 3300, Pago: 2100 },
    { month: "Out", Dívida: 3300, Pago: 2100 },
    { month: "Nov", Dívida: 3300, Pago: 2100 },
    { month: "Dez", Dívida: 3300, Pago: 2100 },
  ]

  // Custom tooltip for charts
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background border rounded-lg shadow-lg p-3 text-sm">
          <p className="font-medium mb-1">{label}</p>
          {payload.map((entry: any, index: number) => (
            <div key={`item-${index}`} className="flex items-center gap-2 my-1">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }} />
              <span className="text-muted-foreground">{entry.name}:</span>
              <span className="font-medium">{formatCurrency(entry.value, currency)}</span>
            </div>
          ))}
        </div>
      )
    }
    return null
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="text-2xl font-bold tracking-tight">{t.debtPlanner || "Planejador de Dívidas"}</h1>
        <div className="flex gap-2">
          <Dialog open={aiPlanDialogOpen} onOpenChange={setAiPlanDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="gap-2">
                <TrendingUp className="h-4 w-4" /> {t.generatePlan || "Gerar Plano"}
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[700px]">
              <DialogHeader>
                <DialogTitle>{t.aiPlanTitle || "Plano de Pagamento Personalizado"}</DialogTitle>
              </DialogHeader>

              <div className="py-4">
                <p className="text-muted-foreground mb-6">
                  {t.aiPlanDescription ||
                    "Nosso assistente financeiro analisará suas dívidas e criará um plano de pagamento personalizado para você."}
                </p>

                {!aiPlanGenerated ? (
                  <div className="text-center py-8">
                    <Button onClick={generateAiPlan} disabled={isLoading}>
                      {isLoading ? t.generating || "Gerando..." : t.generatePlan || "Gerar Plano"}
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-6" ref={printRef}>
                    <div className="flex justify-end space-x-2 mb-4">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="outline" className="gap-2">
                            <Share2 className="h-4 w-4" /> {t.share || "Compartilhar"}
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent>
                          <DropdownMenuItem onClick={handlePrintPDF}>
                            <Printer className="h-4 w-4 mr-2" /> {t.exportPDF || "Exportar PDF"}
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={handleShareByEmail}>
                            <Mail className="h-4 w-4 mr-2" /> {t.sendByEmail || "Enviar por Email"}
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={handleShareByWhatsApp}>
                            <Share2 className="h-4 w-4 mr-2" /> {t.shareViaWhatsApp || "Compartilhar via WhatsApp"}
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <Card>
                        <CardContent className="pt-6">
                          <div className="text-center">
                            <h3 className="text-lg font-medium mb-1">{t.totalDebt || "Dívida Total"}</h3>
                            <p className="text-2xl font-bold">{formatCurrency(aiPlanData.totalDebt, currency)}</p>
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-6">
                          <div className="text-center">
                            <h3 className="text-lg font-medium mb-1">{t.monthlyPayment || "Pagamento Mensal"}</h3>
                            <p className="text-2xl font-bold">{formatCurrency(aiPlanData.monthlyPayment, currency)}</p>
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-6">
                          <div className="text-center">
                            <h3 className="text-lg font-medium mb-1">{t.debtFreeIn || "Livre de Dívidas em"}</h3>
                            <p className="text-2xl font-bold">
                              {aiPlanData.monthsToPayoff} {t.months || "meses"}
                            </p>
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <Card>
                        <CardHeader>
                          <CardTitle>{t.debtDistribution || "Distribuição de Dívidas"}</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="h-[250px]">
                            <ResponsiveContainer width="100%" height="100%">
                              <RechartsPieChart>
                                <Pie
                                  data={aiPlanData.debtDistributionData}
                                  cx="50%"
                                  cy="50%"
                                  innerRadius={60}
                                  outerRadius={80}
                                  paddingAngle={2}
                                  dataKey="value"
                                >
                                  {aiPlanData.debtDistributionData.map((entry: any, index: number) => (
                                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                  ))}
                                </Pie>
                                <Tooltip content={<CustomTooltip />} />
                                <Legend />
                              </RechartsPieChart>
                            </ResponsiveContainer>
                          </div>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle>{t.paymentPlan || "Plano de Pagamento"}</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="h-[250px]">
                            <ResponsiveContainer width="100%" height="100%">
                              <RechartsBarChart data={aiPlanData.paymentPlanData}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                <XAxis dataKey="month" />
                                <YAxis tickFormatter={(value) => formatCurrency(value, currency, true)} />
                                <Tooltip content={<CustomTooltip />} />
                                <Legend />
                                <Bar dataKey="Planejado" fill="#3B82F6" name={t.planned || "Planejado"} />
                                <Bar dataKey="Real" fill="#10B981" name={t.actual || "Real"} />
                              </RechartsBarChart>
                            </ResponsiveContainer>
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    <Card>
                      <CardHeader>
                        <CardTitle>{t.debtEvolution || "Evolução da Dívida"}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="h-[300px]">
                          <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={aiPlanData.debtEvolutionData}>
                              <CartesianGrid strokeDasharray="3 3" vertical={false} />
                              <XAxis dataKey="month" />
                              <YAxis tickFormatter={(value) => formatCurrency(value, currency, true)} />
                              <Tooltip content={<CustomTooltip />} />
                              <Legend />
                              <Line
                                type="monotone"
                                dataKey="Dívida"
                                stroke="#EC4899"
                                name={t.remainingDebt || "Dívida Restante"}
                                strokeWidth={2}
                              />
                              <Line
                                type="monotone"
                                dataKey="Pago"
                                stroke="#10B981"
                                name={t.totalPaid || "Total Pago"}
                                strokeWidth={2}
                              />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      </CardContent>
                    </Card>

                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">{t.recommendations || "Recomendações"}</h3>
                      <ul className="space-y-2 list-disc pl-5">
                        {aiPlanData.recommendations.map((recommendation: string, index: number) => (
                          <li key={index}>{recommendation}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )}
              </div>

              <DialogFooter>
                <Button onClick={() => setAiPlanDialogOpen(false)}>{t.close || "Fechar"}</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <Dialog
            open={dialogOpen}
            onOpenChange={(open) => {
              setDialogOpen(open)
              if (!open) {
                form.reset()
                setEditingDebt(null)
              }
            }}
          >
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" /> {t.addDebt || "Adicionar Dívida"}
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>
                  {editingDebt ? t.editDebt || "Editar Dívida" : t.addDebt || "Adicionar Dívida"}
                </DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="creditor"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t.creditor || "Credor"}</FormLabel>
                          <FormControl>
                            <Input placeholder={t.creditor || "Credor"} {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="amount"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t.debtAmount || "Valor da Dívida"}</FormLabel>
                          <FormControl>
                            <Input type="number" step="0.01" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t.debtDescription || "Descrição da Dívida"}</FormLabel>
                        <FormControl>
                          <Input placeholder={t.debtDescription || "Descrição da Dívida"} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="status"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t.status || "Status"}</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value || "active"}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder={t.selectStatus || "Selecione o status"} />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="active">{t.active || "Ativa"}</SelectItem>
                              <SelectItem value="negotiating">{t.negotiating || "Em negociação"}</SelectItem>
                              <SelectItem value="paid">{t.paid || "Paga"}</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="dueDate"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>{t.dueDate || "Data de Vencimento"}</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button
                                  variant={"outline"}
                                  className={cn(
                                    "w-full pl-3 text-left font-normal",
                                    !field.value && "text-muted-foreground",
                                  )}
                                >
                                  {field.value ? (
                                    format(field.value, "PPP")
                                  ) : (
                                    <span>{t.selectDate || "Selecione a data"}</span>
                                  )}
                                  <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <FormField
                      control={form.control}
                      name="installments"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t.installments || "Parcelas"}</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="installmentAmount"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t.installmentAmount || "Valor da Parcela"}</FormLabel>
                          <FormControl>
                            <Input type="number" step="0.01" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="interestRate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t.interestRate || "Taxa de Juros (%)"}</FormLabel>
                          <FormControl>
                            <Input type="number" step="0.01" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t.notes || "Observações"}</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder={t.notesPlaceholder || "Adicione detalhes adicionais aqui..."}
                            className="resize-none"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                      {t.cancel || "Cancelar"}
                    </Button>
                    <Button type="submit" disabled={isLoading}>
                      {isLoading ? t.saving || "Salvando..." : t.save || "Salvar"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="all" onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="all">{t.allDebts || "Todas as Dívidas"}</TabsTrigger>
          <TabsTrigger value="active">{t.active || "Ativas"}</TabsTrigger>
          <TabsTrigger value="negotiating">{t.negotiating || "Em Negociação"}</TabsTrigger>
          <TabsTrigger value="paid">{t.paid || "Pagas"}</TabsTrigger>
        </TabsList>
        <TabsContent value={activeTab} className="mt-4">
          <div className="grid gap-4 md:grid-cols-2">
            {filteredDebts.length > 0 ? (
              filteredDebts.map((debt) => (
                <Card key={debt.id} className="overflow-hidden relative group">
                  <div
                    className={cn(
                      "h-2 w-full",
                      debt.status === "active"
                        ? "bg-amber-500"
                        : debt.status === "negotiating"
                          ? "bg-blue-500"
                          : "bg-green-500",
                    )}
                  />
                  <CardHeader className="pb-2">
                    <div className="flex justify-between">
                      <CardTitle className="text-lg">{debt.description}</CardTitle>
                      <div className="flex items-center gap-1">
                        {getStatusIcon(debt.status)}
                        <span className={cn("text-sm font-medium capitalize", getStatusColor(debt.status))}>
                          {t[debt.status] || debt.status}
                        </span>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">{t.creditor || "Credor"}</span>
                      <span className="font-medium">{debt.creditor}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">{t.amount || "Valor"}</span>
                      <span className="font-medium">{formatCurrency(debt.amount, currency)}</span>
                    </div>
                    {debt.dueDate && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">{t.dueDate || "Data de Vencimento"}</span>
                        <span className="font-medium">{debt.dueDate}</span>
                      </div>
                    )}
                    {debt.installments && (
                      <>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">{t.installments || "Parcelas"}</span>
                          <span className="font-medium">
                            {debt.installments} x {formatCurrency(debt.installmentAmount || 0, currency)}
                          </span>
                        </div>
                        <div className="space-y-1">
                          <div className="flex justify-between text-sm">
                            <span>{t.paymentProgress || "Progresso de Pagamento"}</span>
                            <span>3/{debt.installments}</span>
                          </div>
                          <Progress value={25} className="h-2" />
                        </div>
                      </>
                    )}
                    {debt.interestRate && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">{t.interestRate || "Taxa de Juros"}</span>
                        <span className="font-medium">{debt.interestRate}%</span>
                      </div>
                    )}
                    {debt.notes && (
                      <div className="mt-2 text-sm text-muted-foreground">
                        <p className="font-medium">{t.notes || "Observações"}:</p>
                        <p>{debt.notes}</p>
                      </div>
                    )}
                  </CardContent>

                  {/* Edit/Delete buttons that appear on hover */}
                  <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                    <Button variant="secondary" size="icon" className="h-8 w-8" onClick={() => handleEdit(debt)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="destructive" size="icon" className="h-8 w-8" onClick={() => handleDelete(debt.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </Card>
              ))
            ) : (
              <Card className="col-span-2 py-8">
                <CardContent className="flex flex-col items-center justify-center text-center">
                  <CheckCircle className="h-12 w-12 text-green-500 mb-4" />
                  <h3 className="text-xl font-semibold mb-2">{t.noDebtsYet || "Nenhuma dívida ainda"}</h3>
                  <p className="text-muted-foreground mb-4">
                    {t.addYourFirstDebt || "Adicione sua primeira dívida para começar a acompanhar"}
                  </p>
                  <Button variant="outline" onClick={() => setDialogOpen(true)}>
                    {t.addDebt || "Adicionar Dívida"}
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>
      </Tabs>

      {debts.length > 0 && (
        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>{t.debtDistribution || "Distribuição de Dívidas"}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsPieChart>
                    <Pie
                      data={debtDistributionData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={2}
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {debtDistributionData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                  </RechartsPieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{t.debtEvolution || "Evolução da Dívida"}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={debtEvolutionData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="month" />
                    <YAxis tickFormatter={(value) => formatCurrency(value, currency, true)} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="Dívida"
                      stroke="#EC4899"
                      name={t.remainingDebt || "Dívida Restante"}
                      strokeWidth={2}
                    />
                    <Line
                      type="monotone"
                      dataKey="Pago"
                      stroke="#10B981"
                      name={t.totalPaid || "Total Pago"}
                      strokeWidth={2}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
