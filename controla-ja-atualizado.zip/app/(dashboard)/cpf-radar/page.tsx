"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AlertCircle, CheckCircle2, Search, TrendingUp } from "lucide-react"
import { cn } from "@/lib/utils"
import { useLanguage } from "@/lib/language-context"
import { translations } from "@/lib/translations"
import { formatCurrency } from "@/lib/currency-formatter"
import { CPFScanner } from "@/components/cpf-radar/cpf-scanner"
import { useSupabase } from "@/lib/supabase-context"
import {
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Legend,
  Tooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
} from "recharts"

export default function CPFRadarPage() {
  const { language, currency } = useLanguage()
  const t = translations[language]
  const [activeTab, setActiveTab] = useState("all")
  const { cpfDebts, addDebt, isLoading } = useSupabase()
  const [filteredDebts, setFilteredDebts] = useState(cpfDebts)

  const [isLoadingExport, setIsLoadingExport] = useState(false);
  const [showConsultantMessage, setShowConsultantMessage] = useState(false);

  // Filter debts when tab changes or cpfDebts changes
  useEffect(() => {
    if (activeTab === "all") {
      setFilteredDebts(cpfDebts)
    } else {
      setFilteredDebts(cpfDebts.filter((debt) => debt.status === activeTab.toLowerCase()))
    }
  }, [activeTab, cpfDebts])

  function getStatusIcon(status: string) {
    switch (status) {
      case "active":
        return <AlertCircle className="h-5 w-5 text-amber-500" />
      case "negotiating":
        return <Search className="h-5 w-5 text-blue-500" />
      case "paid":
        return <CheckCircle2 className="h-5 w-5 text-green-500" />
      default:
        return <AlertCircle className="h-5 w-5 text-amber-500" />
    }
  }

  function getStatusColor(status: string) {
    switch (status) {
      case "active":
        return "text-amber-500"
      case "negotiating":
        return "text-blue-500"
      case "paid":
        return "text-green-500"
      default:
        return "text-amber-500"
    }
  }

  // Data for debt distribution chart
  const debtDistributionData = [
    { name: t.active, value: cpfDebts.filter((d) => d.status === "active").reduce((sum, d) => sum + d.amount, 0) },
    {
      name: t.negotiating,
      value: cpfDebts.filter((d) => d.status === "negotiating").reduce((sum, d) => sum + d.amount, 0),
    },
    { name: t.paid, value: cpfDebts.filter((d) => d.status === "paid").reduce((sum, d) => sum + d.amount, 0) },
  ].filter((item) => item.value > 0)

  // Data for creditor distribution chart
  const creditorDistributionData = cpfDebts.map((debt) => ({
    name: debt.creditor,
    value: debt.amount,
  }))

  const COLORS = ["#8B5CF6", "#EC4899", "#10B981", "#3B82F6", "#F59E0B"]

  // Custom tooltip for charts
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background border rounded-lg shadow-lg p-3 text-sm">
          <p className="font-medium mb-1">{label || payload[0].name}</p>
          {payload.map((entry: any, index: number) => (
            <div key={`item-${index}`} className="flex items-center gap-2 my-1">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }} />
              <span className="text-muted-foreground">{entry.name !== label ? entry.name : t.amount}:</span>
              <span className="font-medium">{formatCurrency(entry.value, currency)}</span>
            </div>
          ))}
        </div>
      )
    }
    return null
  }

  // Function to add a debt to the debt planner
  const addToDebtPlanner = async (cpfDebt: any) => {
    try {
      await addDebt({
        creditor: cpfDebt.creditor,
        amount: cpfDebt.amount,
        description: `Dívida importada do Radar CPF - ${cpfDebt.creditor}`,
        status: cpfDebt.status,
        dueDate: cpfDebt.dueDate,
        installments: cpfDebt.paymentOptions?.[0]?.installments,
        installmentAmount: cpfDebt.paymentOptions?.[0]?.installmentAmount,
        interestRate: 0, // Default value
      })

      // Show success message
      alert("Dívida adicionada ao planejador com sucesso!")
    } catch (error) {
      console.error("Error adding debt to planner:", error)
      alert("Erro ao adicionar dívida ao planejador.")
    }
  }

  const handleExportReport = () => {
    setIsLoadingExport(true);
    setTimeout(() => {
      setIsLoadingExport(false);
      alert("Relatório exportado!");
    }, 2000);
  };

  const handleNegotiateDebts = () => {
    setShowConsultantMessage(true);
    setTimeout(() => {
      setShowConsultantMessage(false);
    }, 5000);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold tracking-tight">{t.cpfRadar}</h1>
        </div>
        <Card>
          <CardContent className="p-6">
            <div className="animate-pulse space-y-4">
              <div className="h-8 w-40 bg-muted rounded"></div>
              <div className="h-20 bg-muted rounded"></div>
              <div className="h-10 w-full bg-muted rounded"></div>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold tracking-tight">{t.cpfRadar}</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{t.searchForDebts}</CardTitle>
        </CardHeader>
        <CardContent>
          <CPFScanner />
        </CardContent>
      </Card>

      {cpfDebts.length > 0 && (
        <>
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <h2 className="text-xl font-semibold">{t.searchResults}</h2>
            <Tabs defaultValue="all" onValueChange={setActiveTab}>
              <TabsList>
                <TabsTrigger value="all">{t.all}</TabsTrigger>
                <TabsTrigger value="active">{t.active}</TabsTrigger>
                <TabsTrigger value="negotiating">{t.negotiating}</TabsTrigger>
                <TabsTrigger value="paid">{t.paid}</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>{t.debtDistribution}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[250px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsPieChart>
                      <Pie
                        data={debtDistributionData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={2}
                        dataKey="value"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {debtDistributionData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip content={<CustomTooltip />} />
                      <Legend />
                    </RechartsPieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>{t.debtByCreditor || "Debt by Creditor"}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[250px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={creditorDistributionData} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
                      <XAxis type="number" />
                      <YAxis dataKey="name" type="category" width={100} />
                      <Tooltip content={<CustomTooltip />} />
                      <Bar dataKey="value" fill="#8B5CF6" name={t.amount} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            {filteredDebts.map((debt) => (
              <Card key={debt.id} className="overflow-hidden">
                <div
                  className={`h-2 w-full ${debt.status === "active" ? "bg-amber-500" : debt.status === "negotiating" ? "bg-blue-500" : "bg-green-500"}`}
                />
                <CardHeader className="pb-2">
                  <div className="flex justify-between">
                    <CardTitle>{debt.creditor}</CardTitle>
                    <div
                      className={cn(
                        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium",
                        debt.status === "active"
                          ? "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-300"
                          : debt.status === "negotiating"
                            ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
                            : "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300",
                      )}
                    >
                      {debt.status === "active" ? t.active : debt.status === "negotiating" ? t.negotiating : t.paid}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">{t.amount}:</span>
                    <span className="font-medium">{formatCurrency(debt.amount, currency)}</span>
                  </div>
                  {debt.dueDate && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">{t.dueDate}:</span>
                      <span className="font-medium">{debt.dueDate}</span>
                    </div>
                  )}

                  <div className="space-y-2">
                    <h4 className="text-sm font-medium">{t.paymentOptions}:</h4>
                    <div className="space-y-2">
                      {debt.paymentOptions?.map((option, index) => (
                        <div key={index} className="rounded-lg border p-3 hover:bg-accent hover:text-accent-foreground">
                          <div className="flex items-center justify-between">
                            <div>
                              <div className="font-medium">
                                {option.installments === 1
                                  ? t.singlePayment
                                  : `${option.installments} ${t.installments}`}
                              </div>
                              <div className="text-sm text-muted-foreground">
                                {option.installments > 1
                                  ? `${formatCurrency(option.installmentAmount, currency)} ${t.perMonth || "per month"}`
                                  : ""}
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="font-medium">
                                {formatCurrency(option.installmentAmount * option.installments, currency)}
                              </div>
                              {option.discount ? (
                                <div className="text-sm text-green-600 dark:text-green-400">
                                  {option.discount}% {t.discount}
                                </div>
                              ) : null}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Button className="w-full gap-2" onClick={() => addToDebtPlanner(debt)}>
                    <TrendingUp className="h-4 w-4" /> {t.addToDebtPlanner}
                  </Button>
                </CardContent>
                <CardFooter className="flex justify-end gap-2">
                  <Button variant="outline" onClick={handleExportReport} disabled={isLoadingExport}>
                    {isLoadingExport ? "Exportando..." : "Exportar Relatório"}
                  </Button>
                  <Button onClick={handleNegotiateDebts}>Negociar Dívidas</Button>
                </CardFooter>
                {showConsultantMessage && (
                  <div className="mt-4 p-4 bg-green-50 text-green-800 rounded-lg">
                    <p className="font-medium">Um de nossos consultores entrará em contato em breve.</p>
                  </div>
                )}
              </Card>
            ))}
          </div>
        </>
      )
    }
  }
