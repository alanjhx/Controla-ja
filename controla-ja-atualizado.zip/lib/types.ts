// Transaction types
export interface Transaction {
  id: string
  description: string
  amount: number
  date: string
  type: "income" | "expense"
  categoryId: string
  cardId?: string
  userId: string
  recurrence?: "one-time" | "weekly" | "monthly" | "yearly"
  tags?: string[]
  notes?: string
}

// Category types
export interface Category {
  id: string
  name: string
  type: "income" | "expense"
  icon?: string
}

// Card types
export interface Card {
  id: string
  name: string
  number: string
  expiryDate: string
  type: string
  balance: number
  limit: number
  userId: string
  color?: string
}

// Debt types
export interface Debt {
  id: string
  name: string
  amount: number
  interestRate: number
  minimumPayment: number
  dueDate: string
  userId: string
  status?: "active" | "negotiating" | "paid"
  paymentOptions?: PaymentOption[]
}

export interface PaymentOption {
  installments: number
  installmentAmount: number
  discount?: number
}

// Goal types
export interface Goal {
  id: string
  name: string
  targetAmount: number
  currentAmount: number
  deadline: string
  userId: string
  icon?: string
}

// CPF debt types
export interface CPFDebt {
  id: string
  creditor: string
  amount: number
  status: "pending" | "negotiating" | "paid"
  dueDate: string
  userId: string
  paymentOptions?: PaymentOption[]
}
