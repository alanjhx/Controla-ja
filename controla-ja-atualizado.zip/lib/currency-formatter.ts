export function formatCurrency(amount: number, currency = "USD", compact = false): string {
  const formatter = new Intl.NumberFormat(currency === "BRL" ? "pt-BR" : currency === "EUR" ? "fr-FR" : "en-US", {
    style: "currency",
    currency: currency,
    minimumFractionDigits: compact ? 0 : 2,
    maximumFractionDigits: 2,
    notation: compact ? "compact" : "standard",
  })

  return formatter.format(amount)
}
