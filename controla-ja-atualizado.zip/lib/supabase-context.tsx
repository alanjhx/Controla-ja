"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { mockTransactions, mockCategories, mockCards, mockDebts, mockGoals, mockCPFDebts } from "@/lib/mock-data"
import type { Transaction, Category, Card, Debt, Goal, CPFDebt } from "@/lib/types"
import { useAuth } from "@/lib/auth-context"

type SupabaseContextType = {
  transactions: Transaction[]
  categories: Category[]
  cards: Card[]
  debts: Debt[]
  goals: Goal[]
  cpfDebts: CPFDebt[]
  isLoading: boolean
  addTransaction: (transaction: Omit<Transaction, "id">) => Promise<Transaction>
  updateTransaction: (id: string, transaction: Partial<Transaction>) => Promise<Transaction>
  deleteTransaction: (id: string) => Promise<void>
  addCard: (card: Omit<Card, "id">) => Promise<Card>
  updateCard: (id: string, card: Partial<Card>) => Promise<Card>
  deleteCard: (id: string) => Promise<void>
  addDebt: (debt: Omit<Debt, "id">) => Promise<Debt>
  updateDebt: (id: string, debt: Partial<Debt>) => Promise<Debt>
  deleteDebt: (id: string) => Promise<void>
  addGoal: (goal: Omit<Goal, "id">) => Promise<Goal>
  updateGoal: (id: string, goal: Partial<Goal>) => Promise<Goal>
  deleteGoal: (id: string) => Promise<void>
  addCPFDebt: (cpfDebt: Omit<CPFDebt, "id">) => Promise<CPFDebt>
  updateCPFDebt: (id: string, cpfDebt: Partial<CPFDebt>) => Promise<CPFDebt>
  deleteCPFDebt: (id: string) => Promise<void>
  refreshCPFDebts: () => Promise<void>
  getTotals: () => { balance: number; income: number; expenses: number; savings: number }
}

const SupabaseContext = createContext<SupabaseContextType>({
  transactions: [],
  categories: [],
  cards: [],
  debts: [],
  goals: [],
  cpfDebts: [],
  isLoading: true,
  addTransaction: async () => ({
    id: "",
    description: "",
    amount: 0,
    date: "",
    type: "expense",
    categoryId: "",
    userId: "",
  }),
  updateTransaction: async () => ({
    id: "",
    description: "",
    amount: 0,
    date: "",
    type: "expense",
    categoryId: "",
    userId: "",
  }),
  deleteTransaction: async () => {},
  addCard: async () => ({ id: "", name: "", number: "", expiryDate: "", type: "", balance: 0, limit: 0, userId: "" }),
  updateCard: async () => ({
    id: "",
    name: "",
    number: "",
    expiryDate: "",
    type: "",
    balance: 0,
    limit: 0,
    userId: "",
  }),
  deleteCard: async () => {},
  addDebt: async () => ({ id: "", name: "", amount: 0, interestRate: 0, minimumPayment: 0, dueDate: "", userId: "" }),
  updateDebt: async () => ({
    id: "",
    name: "",
    amount: 0,
    interestRate: 0,
    minimumPayment: 0,
    dueDate: "",
    userId: "",
  }),
  deleteDebt: async () => {},
  addGoal: async () => ({ id: "", name: "", targetAmount: 0, currentAmount: 0, deadline: "", userId: "" }),
  updateGoal: async () => ({ id: "", name: "", targetAmount: 0, currentAmount: 0, deadline: "", userId: "" }),
  deleteGoal: async () => {},
  addCPFDebt: async () => ({ id: "", creditor: "", amount: 0, status: "pending", dueDate: "", userId: "" }),
  updateCPFDebt: async () => ({ id: "", creditor: "", amount: 0, status: "pending", dueDate: "", userId: "" }),
  deleteCPFDebt: async () => {},
  refreshCPFDebts: async () => {},
  getTotals: () => ({ balance: 0, income: 0, expenses: 0, savings: 0 }),
})

export function SupabaseProvider({ children }: { children: ReactNode }) {
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [cards, setCards] = useState<Card[]>([])
  const [debts, setDebts] = useState<Debt[]>([])
  const [goals, setGoals] = useState<Goal[]>([])
  const [cpfDebts, setCPFDebts] = useState<CPFDebt[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const { user } = useAuth()

  // Carregar dados do localStorage quando o componente montar
  useEffect(() => {
    const loadData = () => {
      try {
        // Carregar transações
        const storedTransactions = localStorage.getItem("fincheck-transactions")
        if (storedTransactions) {
          setTransactions(JSON.parse(storedTransactions))
        } else {
          setTransactions(mockTransactions)
          localStorage.setItem("fincheck-transactions", JSON.stringify(mockTransactions))
        }

        // Carregar categorias
        setCategories(mockCategories)

        // Carregar cartões
        const storedCards = localStorage.getItem("fincheck-cards")
        if (storedCards) {
          setCards(JSON.parse(storedCards))
        } else {
          setCards(mockCards)
          localStorage.setItem("fincheck-cards", JSON.stringify(mockCards))
        }

        // Carregar dívidas
        const storedDebts = localStorage.getItem("fincheck-debts")
        if (storedDebts) {
          setDebts(JSON.parse(storedDebts))
        } else {
          setDebts(mockDebts)
          localStorage.setItem("fincheck-debts", JSON.stringify(mockDebts))
        }

        // Carregar metas
        const storedGoals = localStorage.getItem("fincheck-goals")
        if (storedGoals) {
          setGoals(JSON.parse(storedGoals))
        } else {
          setGoals(mockGoals)
          localStorage.setItem("fincheck-goals", JSON.stringify(mockGoals))
        }

        // Carregar dívidas de CPF
        const storedCPFDebts = localStorage.getItem("fincheck-cpf-debts")
        if (storedCPFDebts) {
          setCPFDebts(JSON.parse(storedCPFDebts))
        } else {
          setCPFDebts(mockCPFDebts)
          localStorage.setItem("fincheck-cpf-debts", JSON.stringify(mockCPFDebts))
        }
      } catch (error) {
        console.error("Erro ao carregar dados:", error)
        // Fallback para dados mock em caso de erro
        setTransactions(mockTransactions)
        setCategories(mockCategories)
        setCards(mockCards)
        setDebts(mockDebts)
        setGoals(mockGoals)
        setCPFDebts(mockCPFDebts)
      } finally {
        setIsLoading(false)
      }
    }

    loadData()
  }, [])

  // Função para adicionar uma nova transação
  const addTransaction = async (transaction: Omit<Transaction, "id">): Promise<Transaction> => {
    const newTransaction = {
      ...transaction,
      id: `transaction-${Date.now()}`,
      userId: user?.id || "1",
    }

    const updatedTransactions = [...transactions, newTransaction]
    setTransactions(updatedTransactions)
    localStorage.setItem("fincheck-transactions", JSON.stringify(updatedTransactions))

    return newTransaction
  }

  // Função para atualizar uma transação existente
  const updateTransaction = async (id: string, transaction: Partial<Transaction>): Promise<Transaction> => {
    const index = transactions.findIndex((t) => t.id === id)
    if (index === -1) throw new Error("Transação não encontrada")

    const updatedTransaction = { ...transactions[index], ...transaction }
    const updatedTransactions = [...transactions]
    updatedTransactions[index] = updatedTransaction
    setTransactions(updatedTransactions)
    localStorage.setItem("fincheck-transactions", JSON.stringify(updatedTransactions))

    return updatedTransaction
  }

  // Função para excluir uma transação
  const deleteTransaction = async (id: string): Promise<void> => {
    const updatedTransactions = transactions.filter((t) => t.id !== id)
    setTransactions(updatedTransactions)
    localStorage.setItem("fincheck-transactions", JSON.stringify(updatedTransactions))
  }

  // Função para adicionar um novo cartão
  const addCard = async (card: Omit<Card, "id">): Promise<Card> => {
    const newCard = {
      ...card,
      id: `card-${Date.now()}`,
      userId: user?.id || "1",
    }

    const updatedCards = [...cards, newCard]
    setCards(updatedCards)
    localStorage.setItem("fincheck-cards", JSON.stringify(updatedCards))

    return newCard
  }

  // Função para atualizar um cartão existente
  const updateCard = async (id: string, card: Partial<Card>): Promise<Card> => {
    const index = cards.findIndex((c) => c.id === id)
    if (index === -1) throw new Error("Cartão não encontrado")

    const updatedCard = { ...cards[index], ...card }
    const updatedCards = [...cards]
    updatedCards[index] = updatedCard
    setCards(updatedCards)
    localStorage.setItem("fincheck-cards", JSON.stringify(updatedCards))

    return updatedCard
  }

  // Função para excluir um cartão
  const deleteCard = async (id: string): Promise<void> => {
    const updatedCards = cards.filter((c) => c.id !== id)
    setCards(updatedCards)
    localStorage.setItem("fincheck-cards", JSON.stringify(updatedCards))
  }

  // Função para adicionar uma nova dívida
  const addDebt = async (debt: Omit<Debt, "id">): Promise<Debt> => {
    const newDebt = {
      ...debt,
      id: `debt-${Date.now()}`,
      userId: user?.id || "1",
    }

    const updatedDebts = [...debts, newDebt]
    setDebts(updatedDebts)
    localStorage.setItem("fincheck-debts", JSON.stringify(updatedDebts))

    return newDebt
  }

  // Função para atualizar uma dívida existente
  const updateDebt = async (id: string, debt: Partial<Debt>): Promise<Debt> => {
    const index = debts.findIndex((d) => d.id === id)
    if (index === -1) throw new Error("Dívida não encontrada")

    const updatedDebt = { ...debts[index], ...debt }
    const updatedDebts = [...debts]
    updatedDebts[index] = updatedDebt
    setDebts(updatedDebts)
    localStorage.setItem("fincheck-debts", JSON.stringify(updatedDebts))

    return updatedDebt
  }

  // Função para excluir uma dívida
  const deleteDebt = async (id: string): Promise<void> => {
    const updatedDebts = debts.filter((d) => d.id !== id)
    setDebts(updatedDebts)
    localStorage.setItem("fincheck-debts", JSON.stringify(updatedDebts))
  }

  // Função para adicionar uma nova meta
  const addGoal = async (goal: Omit<Goal, "id">): Promise<Goal> => {
    const newGoal = {
      ...goal,
      id: `goal-${Date.now()}`,
      userId: user?.id || "1",
    }

    const updatedGoals = [...goals, newGoal]
    setGoals(updatedGoals)
    localStorage.setItem("fincheck-goals", JSON.stringify(updatedGoals))

    return newGoal
  }

  // Função para atualizar uma meta existente
  const updateGoal = async (id: string, goal: Partial<Goal>): Promise<Goal> => {
    const index = goals.findIndex((g) => g.id === id)
    if (index === -1) throw new Error("Meta não encontrada")

    const updatedGoal = { ...goals[index], ...goal }
    const updatedGoals = [...goals]
    updatedGoals[index] = updatedGoal
    setGoals(updatedGoals)
    localStorage.setItem("fincheck-goals", JSON.stringify(updatedGoals))

    return updatedGoal
  }

  // Função para excluir uma meta
  const deleteGoal = async (id: string): Promise<void> => {
    const updatedGoals = goals.filter((g) => g.id !== id)
    setGoals(updatedGoals)
    localStorage.setItem("fincheck-goals", JSON.stringify(updatedGoals))
  }

  // Função para adicionar uma nova dívida de CPF
  const addCPFDebt = async (cpfDebt: Omit<CPFDebt, "id">): Promise<CPFDebt> => {
    const newCPFDebt = {
      ...cpfDebt,
      id: `cpf-debt-${Date.now()}`,
      userId: user?.id || "1",
    }

    const updatedCPFDebts = [...cpfDebts, newCPFDebt]
    setCPFDebts(updatedCPFDebts)
    localStorage.setItem("fincheck-cpf-debts", JSON.stringify(updatedCPFDebts))

    return newCPFDebt
  }

  // Função para atualizar uma dívida de CPF existente
  const updateCPFDebt = async (id: string, cpfDebt: Partial<CPFDebt>): Promise<CPFDebt> => {
    const index = cpfDebts.findIndex((d) => d.id === id)
    if (index === -1) throw new Error("Dívida de CPF não encontrada")

    const updatedCPFDebt = { ...cpfDebts[index], ...cpfDebt }
    const updatedCPFDebts = [...cpfDebts]
    updatedCPFDebts[index] = updatedCPFDebt
    setCPFDebts(updatedCPFDebts)
    localStorage.setItem("fincheck-cpf-debts", JSON.stringify(updatedCPFDebts))

    return updatedCPFDebt
  }

  // Função para excluir uma dívida de CPF
  const deleteCPFDebt = async (id: string): Promise<void> => {
    const updatedCPFDebts = cpfDebts.filter((d) => d.id !== id)
    setCPFDebts(updatedCPFDebts)
    localStorage.setItem("fincheck-cpf-debts", JSON.stringify(updatedCPFDebts))
  }

  // Função para atualizar dívidas de CPF com novos dados
  const refreshCPFDebts = async (): Promise<void> => {
    // Simular busca de novas dívidas
    const newDebts: CPFDebt[] = [
      ...cpfDebts,
      {
        id: `cpf-debt-${Date.now()}-1`,
        creditor: "Banco XYZ",
        amount: 1250.0,
        status: "pending",
        dueDate: "2023-12-15",
        userId: user?.id || "1",
      },
      {
        id: `cpf-debt-${Date.now()}-2`,
        creditor: "Financeira ABC",
        amount: 3780.0,
        status: "negotiating",
        dueDate: "2023-11-30",
        userId: user?.id || "1",
      },
      {
        id: `cpf-debt-${Date.now()}-3`,
        creditor: "Loja de Departamentos",
        amount: 450.0,
        status: "pending",
        dueDate: "2023-12-05",
        userId: user?.id || "1",
      },
    ]

    setCPFDebts(newDebts)
    localStorage.setItem("fincheck-cpf-debts", JSON.stringify(newDebts))
  }

  // Função para calcular totais financeiros
  const getTotals = () => {
    // Calcular saldo total (receitas - despesas)
    const income = transactions.filter((t) => t.type === "income").reduce((acc, curr) => acc + curr.amount, 0)

    const expenses = transactions.filter((t) => t.type === "expense").reduce((acc, curr) => acc + curr.amount, 0)

    const balance = income - expenses

    // Calcular economia (metas atingidas)
    const savings = goals.reduce((acc, curr) => acc + curr.currentAmount, 0)

    return {
      balance,
      income,
      expenses,
      savings,
    }
  }

  return (
    <SupabaseContext.Provider
      value={{
        transactions,
        categories,
        cards,
        debts,
        goals,
        cpfDebts,
        isLoading,
        addTransaction,
        updateTransaction,
        deleteTransaction,
        addCard,
        updateCard,
        deleteCard,
        addDebt,
        updateDebt,
        deleteDebt,
        addGoal,
        updateGoal,
        deleteGoal,
        addCPFDebt,
        updateCPFDebt,
        deleteCPFDebt,
        refreshCPFDebts,
        getTotals,
      }}
    >
      {children}
    </SupabaseContext.Provider>
  )
}

export function useSupabase() {
  return useContext(SupabaseContext)
}
