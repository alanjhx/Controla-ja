"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

interface User {
  id: string
  name: string
  email: string
  avatar: string
  isLoggedIn: boolean
}

interface AuthContextType {
  user: User
  login: (email: string, password: string, rememberMe: boolean) => Promise<boolean>
  logout: () => void
}

const defaultUser: User = {
  id: "",
  name: "",
  email: "",
  avatar: "",
  isLoggedIn: false,
}

export const AuthContext = createContext<AuthContextType>({
  user: defaultUser,
  login: async () => false,
  logout: () => {},
})

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User>(defaultUser)

  // Check for stored user on mount
  useEffect(() => {
    const storedUser = localStorage.getItem("fincheck-user") || sessionStorage.getItem("fincheck-user")

    if (storedUser) {
      try {
        const userData = JSON.parse(storedUser)
        if (userData?.isLoggedIn) {
          setUser(userData)
        }
      } catch (error) {
        console.error("Error parsing stored user:", error)
        // Clear invalid storage
        localStorage.removeItem("fincheck-user")
        sessionStorage.removeItem("fincheck-user")
      }
    }
  }, [])

  const login = async (email: string, password: string, rememberMe: boolean): Promise<boolean> => {
    // For demo purposes, accept any valid email
    if (email.includes("@")) {
      const userData: User = {
        id: "1",
        name: "Adaline Horton",
        email: email,
        avatar: "/placeholder.svg?height=40&width=40",
        isLoggedIn: true,
      }

      // Store user data
      if (rememberMe) {
        localStorage.setItem("fincheck-user", JSON.stringify(userData))
      } else {
        sessionStorage.setItem("fincheck-user", JSON.stringify(userData))
      }

      setUser(userData)
      return true
    }
    return false
  }

  const logout = () => {
    localStorage.removeItem("fincheck-user")
    sessionStorage.removeItem("fincheck-user")
    setUser(defaultUser)
  }

  return <AuthContext.Provider value={{ user, login, logout }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  return useContext(AuthContext)
}

export function useUser() {
  const { user } = useAuth()
  return user
}
