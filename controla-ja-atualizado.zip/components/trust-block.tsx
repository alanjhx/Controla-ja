import { CheckCircle, Shield, Star, Users } from "lucide-react"

export default function TrustBlock() {
  return (
    <section className="bg-gray-50 py-12 sm:py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900">Mais de 10.000 usuários já confiam no Controla Já</h2>
          <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
            Junte-se a milhares de brasileiros que transformaram sua vida financeira com nossa plataforma
          </p>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 text-center">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-teal-100">
              <Users className="h-6 w-6 text-teal-600" />
            </div>
            <h3 className="mt-4 text-lg font-medium text-gray-900">10.000+</h3>
            <p className="mt-2 text-base text-gray-600">Usuários ativos</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 text-center">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-teal-100">
              <Star className="h-6 w-6 text-teal-600" />
            </div>
            <h3 className="mt-4 text-lg font-medium text-gray-900">4.8/5</h3>
            <p className="mt-2 text-base text-gray-600">Avaliação média</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 text-center">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-teal-100">
              <CheckCircle className="h-6 w-6 text-teal-600" />
            </div>
            <h3 className="mt-4 text-lg font-medium text-gray-900">98%</h3>
            <p className="mt-2 text-base text-gray-600">Taxa de satisfação</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 text-center">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-teal-100">
              <Shield className="h-6 w-6 text-teal-600" />
            </div>
            <h3 className="mt-4 text-lg font-medium text-gray-900">100%</h3>
            <p className="mt-2 text-base text-gray-600">Segurança de dados</p>
          </div>
        </div>

        <div className="mt-12 flex flex-wrap justify-center gap-8 grayscale opacity-70">
          {/* Logos of trusted companies/partners */}
          {["Banco do Brasil", "Nubank", "Itaú", "Bradesco", "Santander"].map((bank) => (
            <div key={bank} className="flex items-center justify-center">
              <span className="text-xl font-bold text-gray-400">{bank}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
