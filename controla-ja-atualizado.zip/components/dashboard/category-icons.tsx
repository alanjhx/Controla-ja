"use client"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import {
  Home,
  ShoppingCart,
  Utensils,
  Car,
  Plane,
  CreditCard,
  Briefcase,
  GraduationCap,
  Heart,
  Gift,
  DollarSign,
  Wallet,
  Building,
  Landmark,
} from "lucide-react"
import { useLanguage } from "@/lib/language-context"
import { translations } from "@/lib/translations"

interface CategoryIconsProps {
  onSelect: (categoryId: string) => void
  selectedId?: string
  type?: "expense" | "income" | "all"
  className?: string
}

export function CategoryIcons({ onSelect, selectedId, type = "all", className }: CategoryIconsProps) {
  const { language } = useLanguage()
  const t = translations[language]

  const expenseCategories = [
    { id: "housing", name: t.housing || "Moradia", icon: <Home className="h-4 w-4" /> },
    { id: "food", name: t.food || "Alimentação", icon: <Utensils className="h-4 w-4" /> },
    { id: "shopping", name: t.shopping || "Compras", icon: <ShoppingCart className="h-4 w-4" /> },
    { id: "transportation", name: t.transportation || "Transporte", icon: <Car className="h-4 w-4" /> },
    { id: "travel", name: t.travel || "Viagem", icon: <Plane className="h-4 w-4" /> },
    { id: "bills", name: t.bills || "Contas", icon: <CreditCard className="h-4 w-4" /> },
    { id: "education", name: t.education || "Educação", icon: <GraduationCap className="h-4 w-4" /> },
    { id: "health", name: t.health || "Saúde", icon: <Heart className="h-4 w-4" /> },
    { id: "gifts", name: t.gifts || "Presentes", icon: <Gift className="h-4 w-4" /> },
  ]

  const incomeCategories = [
    { id: "salary", name: t.salary || "Salário", icon: <Wallet className="h-4 w-4" /> },
    { id: "freelance", name: t.freelance || "Freelance", icon: <Briefcase className="h-4 w-4" /> },
    { id: "investments", name: t.investments || "Investimentos", icon: <DollarSign className="h-4 w-4" /> },
    { id: "rental", name: t.rental || "Aluguel", icon: <Building className="h-4 w-4" /> },
    { id: "business", name: t.business || "Negócio", icon: <Landmark className="h-4 w-4" /> },
  ]

  const categories =
    type === "expense"
      ? expenseCategories
      : type === "income"
        ? incomeCategories
        : [...expenseCategories, ...incomeCategories]

  return (
    <div className={cn("grid grid-cols-3 sm:grid-cols-5 gap-2", className)}>
      {categories.map((category) => (
        <Button
          key={category.id}
          type="button"
          variant={selectedId === category.id ? "default" : "outline"}
          className={cn(
            "h-16 flex flex-col gap-1 items-center justify-center",
            selectedId === category.id ? "border-2 border-primary" : "",
          )}
          onClick={() => onSelect(category.id)}
        >
          {category.icon}
          <span className="text-xs">{category.name}</span>
        </Button>
      ))}
    </div>
  )
}
