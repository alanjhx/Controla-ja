"use client"

import { useState } from "react"
import type { Transaction, Category } from "@/lib/types"
import { mockCategories } from "@/lib/mock-data"
import { cn } from "@/lib/utils"
import { format } from "date-fns"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { ChevronRight } from "lucide-react"
import { useLanguage } from "@/lib/language-context"
import { translations } from "@/lib/translations"
import { formatCurrency } from "@/lib/currency-formatter"

interface TransactionListProps {
  transactions: Transaction[]
  className?: string
  onViewAll?: () => void
}

export function TransactionList({ transactions, className, onViewAll }: TransactionListProps) {
  const { language, currency } = useLanguage()
  const t = translations[language]
  const [filter, setFilter] = useState("recently")
  const [filteredTransactions, setFilteredTransactions] = useState([...transactions])

  const getCategoryById = (id: string): Category | undefined => {
    return mockCategories.find((category) => category.id === id)
  }

  const handleFilterChange = (value: string) => {
    setFilter(value)

    const sorted = [...transactions]

    if (value === "recently") {
      // Ordenar por data mais recente
      sorted.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    } else if (value === "oldest") {
      // Ordenar por data mais antiga
      sorted.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    } else if (value === "more") {
      // Ordenar por valor mais alto
      sorted.sort((a, b) => b.amount - a.amount)
    }

    setFilteredTransactions(sorted)
  }

  return (
    <Card className={cn("border-none bg-black text-white rounded-xl shadow-sm h-full", className)}>
      <CardHeader className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-2 gap-2">
        <CardTitle className="text-md font-medium">{t.transactionHistory}</CardTitle>
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Tabs value={filter} onValueChange={handleFilterChange} className="w-full sm:w-auto">
            <TabsList className="h-8 w-full sm:w-auto grid grid-cols-3 bg-gray-800/50">
              <TabsTrigger value="recently" className="text-xs">
                {t.recently}
              </TabsTrigger>
              <TabsTrigger value="oldest" className="text-xs">
                {t.oldest}
              </TabsTrigger>
              <TabsTrigger value="more" className="text-xs">
                {t.more}
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="grid grid-cols-12 px-4 py-2 text-xs font-medium text-gray-400">
          <div className="col-span-5 sm:col-span-4">{t.description}</div>
          <div className="col-span-3 sm:col-span-3">{t.type}</div>
          <div className="col-span-2 sm:col-span-2">{t.date}</div>
          <div className="col-span-2 sm:col-span-3 text-right">{t.amount}</div>
        </div>
        <div className="divide-y divide-gray-800">
          {filteredTransactions.slice(0, 5).map((transaction) => {
            const category = getCategoryById(transaction.categoryId)
            return (
              <div key={transaction.id} className="grid grid-cols-12 items-center px-4 py-3 hover:bg-gray-800/30">
                <div className="col-span-5 sm:col-span-4 flex items-center gap-2">
                  <div className="font-medium truncate">{transaction.description}</div>
                </div>
                <div className="col-span-3 sm:col-span-3">
                  <div
                    className={cn(
                      "inline-flex items-center rounded-full px-2 py-1 text-xs font-medium",
                      category?.type === "income" ? "bg-green-900/70 text-green-300" : "bg-red-900/70 text-red-300",
                    )}
                  >
                    {t[category?.name.toLowerCase() || ""] || category?.name}
                  </div>
                </div>
                <div className="col-span-2 sm:col-span-2 text-xs sm:text-sm">
                  {format(new Date(transaction.date), "dd.MM.yyyy")}
                </div>
                <div
                  className={cn(
                    "col-span-2 sm:col-span-3 text-right font-medium",
                    transaction.type === "income" ? "text-green-400" : "text-red-400",
                  )}
                >
                  {transaction.type === "income" ? "+" : "-"}
                  {formatCurrency(transaction.amount, currency)}
                </div>
              </div>
            )
          })}
        </div>
        <div className="p-4 text-center">
          <Button variant="ghost" size="sm" className="gap-1 text-blue-400 hover:text-blue-300" onClick={onViewAll}>
            {t.viewAllTransactions} <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
