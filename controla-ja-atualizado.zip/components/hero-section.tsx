import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, BarChart2, PieChart, TrendingUp } from "lucide-react"

export default function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-white py-16 sm:py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="max-w-2xl">
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight text-gray-900 leading-tight">
              Assuma o controle das suas finanças com o <span className="text-teal-600">Controla Já</span>
            </h1>
            <p className="mt-6 text-lg text-gray-600">
              Simplifique sua vida financeira com o sistema que já ajudou milhares de brasileiros a sair do vermelho.
            </p>
            <div className="mt-10 flex flex-col sm:flex-row gap-4">
              <Link href="#pricing">
                <Button className="bg-teal-600 hover:bg-teal-700 text-white px-8 py-6 text-base">
                  Ver Planos e Assinar Agora
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link href="#features">
                <Button variant="outline" className="px-8 py-6 text-base">
                  Conhecer Funcionalidades
                </Button>
              </Link>
            </div>
            <div className="mt-8 flex items-center">
              <div className="flex -space-x-2">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="inline-block h-8 w-8 rounded-full bg-gray-200 ring-2 ring-white" />
                ))}
              </div>
              <p className="ml-4 text-sm text-gray-600">Junte-se a milhares de usuários satisfeitos</p>
            </div>
          </div>
          <div className="relative lg:h-[500px] flex items-center justify-center">
            <div className="relative w-full max-w-lg">
              {/* Background decorative elements */}
              <div className="absolute top-0 -left-4 w-72 h-72 bg-teal-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob"></div>
              <div className="absolute top-0 -right-4 w-72 h-72 bg-cyan-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob animation-delay-2000"></div>
              <div className="absolute -bottom-8 left-20 w-72 h-72 bg-emerald-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob animation-delay-4000"></div>

              {/* Dashboard mockup */}
              <div className="relative bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-200">
                <div className="h-10 bg-gray-100 flex items-center px-4 border-b border-gray-200">
                  <div className="flex space-x-2">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  </div>
                </div>
                <div className="p-6">
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="bg-teal-50 p-4 rounded-lg">
                      <TrendingUp className="h-6 w-6 text-teal-600 mb-2" />
                      <h3 className="font-medium text-gray-900">Receitas</h3>
                      <p className="text-2xl font-bold text-teal-600">R$ 5.240,00</p>
                    </div>
                    <div className="bg-red-50 p-4 rounded-lg">
                      <TrendingUp className="h-6 w-6 text-red-600 mb-2" />
                      <h3 className="font-medium text-gray-900">Despesas</h3>
                      <p className="text-2xl font-bold text-red-600">R$ 3.120,00</p>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h3 className="font-medium text-gray-900 mb-2">Resumo Mensal</h3>
                      <div className="h-40 flex items-center justify-center">
                        <BarChart2 className="h-32 w-32 text-gray-400" />
                      </div>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h3 className="font-medium text-gray-900 mb-2">Categorias</h3>
                      <div className="h-40 flex items-center justify-center">
                        <PieChart className="h-32 w-32 text-gray-400" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
