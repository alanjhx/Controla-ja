import { Star } from "lucide-react"

const testimonials = [
  {
    content:
      "O Controla Já mudou completamente minha relação com o dinheiro. Em apenas 3 meses, consegui pagar todas as minhas dívidas e começar a poupar.",
    author: "Mariana Silva",
    role: "Professora",
    rating: 5,
  },
  {
    content:
      "Nunca fui organizado com minhas finanças, mas o Controla Já tornou tudo tão simples que agora sei exatamente para onde vai cada centavo.",
    author: "Carlos Oliveira",
    role: "Engenheiro",
    rating: 5,
  },
  {
    content:
      "A integração com meus bancos e cartões economiza muito tempo. As categorias automáticas são precisas e os relatórios me ajudam a tomar melhores decisões.",
    author: "Juliana Costa",
    role: "Advogada",
    rating: 5,
  },
  {
    content:
      "Estou usando há 6 meses e já consegui juntar dinheiro para minha viagem dos sonhos. Os alertas me ajudam a não gastar mais do que deveria.",
    author: "Pedro Santos",
    role: "Designer",
    rating: 4,
  },
  {
    content:
      "O suporte ao cliente é excelente! Sempre que tive dúvidas, fui atendido rapidamente. O aplicativo é intuitivo e fácil de usar.",
    author: "Ana Beatriz",
    role: "Médica",
    rating: 5,
  },
  {
    content:
      "Finalmente encontrei um app que realmente funciona para controlar minhas finanças. A versão premium vale cada centavo pelo tempo que economizo.",
    author: "Rafael Mendes",
    role: "Empresário",
    rating: 5,
  },
]

export default function TestimonialsSection() {
  return (
    <section id="testimonials" className="py-16 sm:py-24 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">O que nossos clientes dizem</h2>
          <p className="mt-4 text-lg text-gray-600">
            Milhares de brasileiros já transformaram sua vida financeira com o Controla Já.
          </p>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="rounded-lg border border-gray-100 bg-white p-6 shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex gap-0.5">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-5 w-5 ${
                      i < testimonial.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                    }`}
                  />
                ))}
              </div>
              <p className="mt-4 text-gray-600 italic">"{testimonial.content}"</p>
              <div className="mt-6 flex items-center">
                <div className="h-10 w-10 rounded-full bg-gradient-to-r from-teal-400 to-teal-600 flex items-center justify-center text-white font-bold">
                  {testimonial.author.charAt(0)}
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-900">{testimonial.author}</p>
                  <p className="text-sm text-gray-500">{testimonial.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
