"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"
import { cn } from "@/lib/utils"

const plans = [
  {
    name: "Plano Manual",
    description: "Ideal para quem está começando a organizar as finanças",
    monthlyPrice: 15.9,
    yearlyPrice: 159.9,
    features: [
      "Controle manual de receitas e despesas",
      "Categorização de transações",
      "Relatórios básicos",
      "Metas financeiras",
      "Acesso ao aplicativo mobile",
      "Suporte por email",
    ],
    cta: "Assinar Agora",
    popular: false,
  },
  {
    name: "Plano Conectado",
    description: "Perfeito para quem quer automatizar o controle financeiro",
    monthlyPrice: 39.9,
    yearlyPrice: 399.9,
    features: [
      "Todas as funcionalidades do Plano Manual",
      "Integração com bancos e cartões",
      "Importação automática de transações",
      "Categorização inteligente com IA",
      "Relatórios avançados",
      "Alertas personalizados",
      "Suporte prioritário",
    ],
    cta: "Assinar Agora",
    popular: true,
  },
  {
    name: "Plano Conectado Plus",
    description: "Para quem busca o máximo em controle financeiro",
    monthlyPrice: 59.9,
    yearlyPrice: 599.9,
    features: [
      "Todas as funcionalidades do Plano Conectado",
      "Consultoria financeira mensal",
      "Planejamento de investimentos",
      "Simulação de cenários financeiros",
      "Relatórios para declaração de IR",
      "Acesso antecipado a novos recursos",
      "Suporte VIP 24/7",
    ],
    cta: "Assinar Agora",
    popular: false,
  },
]

export default function PricingSection() {
  const [billingCycle, setBillingCycle] = useState<"monthly" | "yearly">("monthly")

  return (
    <section id="pricing" className="py-16 sm:py-24 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">Escolha o plano ideal para você</h2>
          <p className="mt-4 text-lg text-gray-600">
            Temos opções para todos os perfis, com preços acessíveis e benefícios exclusivos.
          </p>
        </div>

        <div className="mt-8 flex justify-center">
          <div className="relative flex rounded-full bg-gray-100 p-1">
            <button
              type="button"
              className={cn(
                "relative rounded-full py-2 px-6 text-sm font-medium transition-all",
                billingCycle === "monthly" ? "bg-white shadow-sm text-gray-900" : "text-gray-500 hover:text-gray-900",
              )}
              onClick={() => setBillingCycle("monthly")}
            >
              Mensal
            </button>
            <button
              type="button"
              className={cn(
                "relative ml-0.5 rounded-full py-2 px-6 text-sm font-medium transition-all",
                billingCycle === "yearly" ? "bg-white shadow-sm text-gray-900" : "text-gray-500 hover:text-gray-900",
              )}
              onClick={() => setBillingCycle("yearly")}
            >
              Anual
              <span className="absolute -right-1 -top-1 flex h-5 w-16 -translate-y-1/2 translate-x-full items-center justify-center rounded-full bg-teal-600 px-2 py-0.5 text-xs text-white">
                Economize 16%
              </span>
            </button>
          </div>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-8 lg:grid-cols-3">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={cn(
                "relative flex flex-col rounded-2xl border bg-white shadow-sm transition-all",
                plan.popular ? "border-teal-600 scale-105 shadow-md lg:-mt-4" : "border-gray-200",
              )}
            >
              {plan.popular && (
                <div className="absolute -top-5 left-0 right-0 mx-auto w-32 rounded-full bg-teal-600 px-3 py-2 text-center text-sm font-medium text-white">
                  Mais Popular
                </div>
              )}

              <div className="p-8">
                <h3 className="text-xl font-semibold text-gray-900">{plan.name}</h3>
                <p className="mt-2 text-gray-600">{plan.description}</p>
                <p className="mt-6 flex items-baseline">
                  <span className="text-4xl font-bold tracking-tight text-gray-900">
                    {billingCycle === "monthly"
                      ? `R$ ${plan.monthlyPrice.toFixed(2)}`
                      : `R$ ${plan.yearlyPrice.toFixed(2)}`}
                  </span>
                  <span className="ml-1 text-sm font-medium text-gray-500">
                    /{billingCycle === "monthly" ? "mês" : "ano"}
                  </span>
                </p>
                <Button
                  className={cn(
                    "mt-6 w-full",
                    plan.popular ? "bg-teal-600 hover:bg-teal-700" : "bg-gray-900 hover:bg-gray-800",
                  )}
                >
                  {plan.cta}
                </Button>
              </div>

              <div className="flex flex-1 flex-col justify-between rounded-b-2xl bg-gray-50 p-8">
                <div>
                  <h4 className="text-sm font-medium text-gray-900">Inclui:</h4>
                  <ul className="mt-4 space-y-3">
                    {plan.features.map((feature) => (
                      <li key={feature} className="flex items-start">
                        <Check className="h-5 w-5 flex-shrink-0 text-teal-600" />
                        <span className="ml-3 text-sm text-gray-600">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="text-gray-600">Todos os planos incluem 7 dias de teste grátis. Cancele a qualquer momento.</p>
        </div>
      </div>
    </section>
  )
}
