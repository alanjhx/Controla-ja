"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Loader2, Search, AlertCircle, CheckCircle, Clock } from "lucide-react"
import { useSupabase } from "@/lib/supabase-context"
import { formatCurrency } from "@/lib/currency-formatter"
import { useLanguage } from "@/lib/language-context"

export function CPFScanner() {
  const [cpf, setCpf] = useState("")
  const [isScanning, setIsScanning] = useState(false)
  const [activeTab, setActiveTab] = useState("all")
  const { cpfDebts, refreshCPFDebts } = useSupabase()
  const { currency } = useLanguage()

  const handleScan = async () => {
    if (!cpf || cpf.length < 11) return

    setIsScanning(true)

    try {
      // Simular busca de dívidas no CPF
      await new Promise((resolve) => setTimeout(resolve, 2000))
      await refreshCPFDebts()
    } catch (error) {
      console.error("Erro ao buscar dívidas:", error)
    } finally {
      setIsScanning(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "paid":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "pending":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
      case "negotiating":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "paid":
        return <CheckCircle className="h-4 w-4 mr-1" />
      case "pending":
        return <AlertCircle className="h-4 w-4 mr-1" />
      case "negotiating":
        return <Clock className="h-4 w-4 mr-1" />
      default:
        return null
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "paid":
        return "Pago"
      case "pending":
        return "Pendente"
      case "negotiating":
        return "Em Negociação"
      default:
        return status
    }
  }

  const filteredDebts = cpfDebts.filter((debt) => {
    if (activeTab === "all") return true
    return debt.status === activeTab
  })

  const totalDebt = filteredDebts.reduce((acc, curr) => acc + curr.amount, 0)

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Consulta de CPF</CardTitle>
          <CardDescription>
            Verifique se há dívidas ou restrições em seu CPF. Esta consulta é simulada e não acessa dados reais.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-3">
            <Input
              placeholder="Digite seu CPF (apenas números)"
              value={cpf}
              onChange={(e) => setCpf(e.target.value.replace(/\D/g, "").slice(0, 11))}
              maxLength={11}
              className="flex-1"
            />
            <Button onClick={handleScan} disabled={isScanning || cpf.length < 11}>
              {isScanning ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Consultando
                </>
              ) : (
                <>
                  <Search className="mr-2 h-4 w-4" /> Consultar CPF
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {cpfDebts.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Resultado da Consulta</CardTitle>
            <CardDescription>Foram encontradas {cpfDebts.length} dívidas associadas a este CPF.</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="all">Todas</TabsTrigger>
                <TabsTrigger value="pending">Pendentes</TabsTrigger>
                <TabsTrigger value="negotiating">Em Negociação</TabsTrigger>
                <TabsTrigger value="paid">Pagas</TabsTrigger>
              </TabsList>
              <TabsContent value={activeTab} className="mt-4">
                <div className="rounded-md border">
                  <div className="grid grid-cols-12 p-3 text-sm font-medium bg-muted/50">
                    <div className="col-span-5">Credor</div>
                    <div className="col-span-3">Status</div>
                    <div className="col-span-2">Vencimento</div>
                    <div className="col-span-2 text-right">Valor</div>
                  </div>
                  <div className="divide-y">
                    {filteredDebts.map((debt) => (
                      <div key={debt.id} className="grid grid-cols-12 p-3 items-center">
                        <div className="col-span-5 font-medium">{debt.creditor}</div>
                        <div className="col-span-3">
                          <Badge variant="outline" className={getStatusColor(debt.status)}>
                            {getStatusIcon(debt.status)}
                            {getStatusText(debt.status)}
                          </Badge>
                        </div>
                        <div className="col-span-2 text-sm">{new Date(debt.dueDate).toLocaleDateString("pt-BR")}</div>
                        <div className="col-span-2 text-right font-medium">{formatCurrency(debt.amount, currency)}</div>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="mt-4 flex justify-between items-center p-3 bg-muted/30 rounded-md">
                  <span className="font-medium">Total:</span>
                  <span className="font-bold">{formatCurrency(totalDebt, currency)}</span>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
          <CardFooter className="flex justify-end gap-2">
            <Button variant="outline">Exportar Relatório</Button>
            <Button>Negociar Dívidas</Button>
          </CardFooter>
        </Card>
      )}
    </div>
  )
}
